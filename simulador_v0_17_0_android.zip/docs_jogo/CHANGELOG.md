## 0.17.0 — Integração completa (2026-11-24)

Versão unificada preservando 100% dos recursos da v0.15.13 e integrando todos os novos sistemas no motor, economia, persistência SQLite, painéis, interface web/Android e CLI:

- **Livros (`sim/livros.py`)**: catálogo expandido de 28 para 129 obras reais auditadas, com filtro por gênero, busca, interesses literários e ganhos cognitivos por gênero (`GENERO_COGNICAO`).
- **Conhecidos (`sim/conhecidos.py`)**: opção de conhecer colegas no trabalho (respeitando vagas da empresa) e criação automática de família (`Família <sobrenome>`) para cada conhecido.
- **Educação Brasileira (`sim/educacao_br.py`)**: ENEM anual, ingresso via SISU, PROUNI (50%/100%), FIES ou vestibular em 16 universidades reais e 7 cursos, iniciação científica (bolsa mensal) e pós-graduação (especialização, mestrado e doutorado com bônus salarial).
- **Carreiras, Empresas e Política (`sim/carreiras.py`)**: concursos públicos com estabilidade funcional (`engine._work`), abertura/encerramento de empresa própria (micro e pequena) com lucro mensal, filiação partidária, atos de campanha e eleições para vereador, prefeito, deputado, senador, governador e presidente.
- **Mundo, Cidades, Imóveis, Bancos e Notícias (`sim/mundo.py`)**: 14 cidades brasileiras com fator regional de custo de vida, compra/aluguel/venda de imóveis e veículos, investimentos (poupança, tesouro, ações), empréstimos bancários e noticiário mensal/eleitoral.
- **Integração completa**: `models.py` (`Game`), `economy.py`, `engine.py`, `persistence.py` (schema v17 compatível com saves v1–v16), `views.py`, `panels.py`, `ui_web.py`, `ui_cli.py` (opções 15–21), `assets/web/js/{app,panels}.js`, `build.gradle.kts` (`versionCode 1700000`) e suíte completa de 299 testes passando.

## 0.15.1 — G2a: foco do período (2026-11-24)
- O jogador escolhe: o foco (equilibrado, estudar, trabalhar, socializar, descansar) pelo botão "Foco"; vale até mudar.
- Consequência: estudar = +6 no desempenho escolar, cognição sobe devagar, cansa; trabalhar = extra de 3% da renda se empregado, cansa; socializar = 1,5× chance de amizade; descansar = recupera saúde. Equilibrado não muda nada (o mundo fica idêntico ao de antes).
- Correção G1: efeitos de personalidade das decisões usavam escala 0–1; a escala real é 1–99.
- Não feito: escolha da área de estudo (G2b).

## 0.15.0 — G1: eventos com decisão (2026-11-24)
- O jogador escolhe: entre 3 opções de uma situação sorteada (ou "decidir por mim"). Consequência: saúde, patrimônio, cognição e personalidade mudam um pouco e a escolha entra na biografia (categoria "decisao").
- O avanço para na decisão (intervalo mínimo de 3 meses; ~18%/mês). Sorteio por gerador local: o mundo simulado não muda.
- Save v15 (guarda a decisão pendente; v1–v14 abrem sem pendência). Interface para toque (botões altos).
- Jogo e projeto Android unificados em um só pacote; versionCode 1500000.

# CHANGELOG

## 0.15.13 — G1b: consequências com atraso nas decisões (2026-11-24)
- O jogador escolhe: nas decisões "Festa na véspera da prova" (ir à festa) e "Prova difícil amanhã" (deixar para lá e brincar), a escolha agora tem um desfecho depois.
- Consequência: 2 meses depois da festa e 1 mês depois de brincar, a nota sai baixa e entra na biografia como "Consequência: ..."; efeito: +1 conscienciosidade (e −1 saúde no caso de brincar). Valores e textos ILUSTRATIVOS, escritos sem consulta ao dono.
- Framework: qualquer opção pode ter `depois=(meses, texto, efeitos)`; agendado em `game.decisions["depois"]` (sem novo schema; saves antigos funcionam) e aplicado por `decisions.atrasadas` a cada mês. Mundo simulado e rng intactos. 292 testes OK; versionCode 1501300.
- Não feito: só 2 opções usam o atraso; as demais 40+ opções ainda não têm desfecho posterior.

## 0.15.12 — barra da data enxuta (2026-11-24)
Micro update só de interface; motor, regras, saves e RNG intactos.
- Alterado (`web/js/app.js`): os botões Amigos, Conhecer, Encontros e Livros saíram da barra da data (seis botões apertavam em telas pequenas) e foram para um único botão **Ações**, que abre a lista com os quatro. A barra volta a ter Foco, Ações e Menu.
- Não verificado visualmente (sem captura de tela): conferir no navegador/celular. 290 testes OK; versionCode 1501200.

## 0.15.11 — G4a: livros, lote 1 e leitura (2026-11-24)
- Novo `sim/livros.py`: catálogo de METADADOS (id, título, autor, ano, gênero, nível; nunca o texto) com o **lote 1 de 28 obras**, escritas de memória pela IA: **AUDITAR item a item** antes de ampliar (meta ~1.000, ~100 por lote).
- O jogador escolhe: botão "Livros" → um livro por mês. Exige idade (nível 1/2/3 = 6/12/15 anos) e compreensão verbal (15/30/45); o motivo aparece ao lado de cada obra bloqueada.
- Consequência: na 1ª leitura de cada obra, 30% de +1 em compreensão verbal (até o potencial); nível 3 também 15% de +1 em raciocínio lógico; evento na biografia. Reler não é oferecido. Valores ILUSTRATIVOS.
- Save: chave opcional `livros` em `meta` (sem novo schema). 290 testes OK; versionCode 1501100.
- Não feito: interesses por gênero, leitura que leva vários meses, lotes 2+ do catálogo, NPCs lendo.

## 0.15.10 — G3g: onde conhecer alguém (2026-11-24)
- O jogador escolhe: ao tocar em "Conhecer", se estuda ou cursa faculdade, escolhe o lugar: vizinhança (padrão), escola ou faculdade. Sem escola/faculdade, o botão age direto como antes.
- Consequência: escola → o conhecido também estuda, com idade ±1 (colega de turma: amizade esfria menos e pesa mais, regras de colegas já existentes); faculdade → o conhecido cursa, é adulto e tem idade ±4. Evento "Conheceu X na escola/faculdade". Regras de idade preservadas (menor só conhece menor; adulto só adulto).
- Não muda o schema nem o mundo simulado. 287 testes OK; versionCode 1501000.
- Não feito (resto da G3): trabalho como lugar (colega de empresa), família própria dos conhecidos, uniões do mesmo sexo.

## 0.15.9 — G3f: memória do relacionamento (2026-11-24)
- O jogador escolhe: quanto investir em cada amigo (conversar/convidar); agora o jogo lembra. Na lista "Amigos" cada um mostra "N momento(s) juntos" e, com ≥6, "amizade próxima".
- Consequência: amizade próxima esfria com ×0,7 da chance, para sempre (soma-se aos efeitos de conversa/convite). Valores ILUSTRATIVOS, escolhidos sem consulta ao dono. Só vale para o par jogador–amigo.
- Save: chave opcional `memoria` em `meta` (sem novo schema). 285 testes OK; versionCode 1500900.
- Não feito (resto da G3): família/escola/trabalho dos conhecidos, uniões do mesmo sexo, memória no namoro.

## 0.15.8 — G3e: terminar e pedir em casamento (2026-11-24)
- O jogador escolhe: com par de namoro, "Encontros" abre a tela "Namoro" com **Pedir em casamento** e **Terminar o namoro**.
- Consequência do pedido: só com ≥6 meses de namoro e ambos ≥18; 1 pedido por mês; o par aceita com chance 50% + 1,4 pp por mês de namoro (teto 100% aos 36 meses) — aceito: casam; recusado: segue o namoro, registrado na biografia. Terminar: namoro desfeito, −1 de saúde, eventos para os dois. Valores ILUSTRATIVOS, escolhidos sem consulta ao dono.
- Sorteio local (o `game.rng` não é usado). Sem novo schema. 283 testes OK; versionCode 1500800.
- Não feito (resto da G3): memória do relacionamento, família/escola/trabalho dos conhecidos, uniões do mesmo sexo.

## 0.15.7 — G3d: aplicativo de encontros, só ≥18 (2026-11-24)
- O jogador escolhe: botão "Encontros" → 3 candidatos (nome, idade) → escolhe um ou nenhum; 1 escolha por mês. Os candidatos mudam a cada mês.
- Regra de idade (escrita na tela): só maiores de 18 anos, solteiros; todos os candidatos têm ≥18 e diferença de idade ≤10 anos; menor de 18 vê só o aviso.
- Consequência: o escolhido nasce como personagem novo (traços próprios, persistido) e começa a namorar o jogador (daí valem as regras de namoro/casamento já existentes). Sorteio local; `game.rng` restaurado.
- Limitação: só sexo diferente (mesmas regras do casamento atual; uniões do mesmo sexo seguem pendentes no ROADMAP). Sem novo schema. 281 testes OK; versionCode 1500700.
- Não feito (resto da G3): memória do relacionamento, família/escola/trabalho dos conhecidos, ações do jogador dentro do namoro (terminar, pedir em casamento).

## 0.15.6 — G3c: convidar amigo para sair (2026-11-24)
- O jogador escolhe: em "Amigos", para cada amigo, "Conversar" ou "Convidar para sair" (só uma das duas por mês por amigo).
- Consequência do convite: a amizade esfria com 30% da chance por 12 meses (conversa: 50%); +0,5 de saúde; custa 3% do salário mínimo (R$ 45 com o mínimo de R$ 1.500; menores de 18 não pagam) e exige patrimônio suficiente. Evento na biografia dos dois. Valores ILUSTRATIVOS, escolhidos sem consulta ao dono.
- Save: chave opcional `convites` em `meta` (sem novo schema). 279 testes OK; versionCode 1500600.
- Não feito (resto da G3): aprofundar amizade (afinidade/memória), namoro, app de relacionamentos (só ≥18), família/escola/trabalho do conhecido.

## 0.15.5 — "Conhecer" limitado a 1 por mês (2026-11-24)
- O jogador escolhe: quando conhecer alguém novo; só 1 pessoa por mês (antes, vários toques seguidos enchiam o círculo de 8 amigos). Consequência: no mesmo mês o jogo avisa para tentar no próximo.
- Estado: marca `(-1, id do jogador)` em `game.convivio` (já salvo; sem novo schema). 277 testes OK; versionCode 1500500.

## 0.15.4 — G3b: conversar com amigo (2026-11-24)
- O jogador escolhe: botão "Amigos" na barra da data → lista dos amigos vivos → conversar (1 vez por mês por amigo).
- Consequência: por 12 meses após a última conversa a amizade esfria com metade da chance; +0,2 de saúde (ilustrativo); evento na biografia dos dois. Sem conversa, o mundo fica idêntico (mesmo nº de sorteios do rng).
- Save: chave opcional `convivio` em `meta` (sem novo schema). 277 testes OK; versionCode 1500400.
- Não feito (resto da G3): convidar/aprofundar amizade, namoro, app de relacionamentos, família/escola/trabalho do conhecido, limite de "Conhecer" por mês.

## 0.15.3 — G3a: conhecer alguém (2026-11-24)
- O jogador escolhe: tocar em "Conhecer" (barra da data) para conhecer uma pessoa nova.
- Consequência: nasce um personagem novo (nome, idade, personalidade e cognição próprios, persistido) e já vira amigo do jogador (máx. 8 amigos vivos; a ação recusa com aviso se cheio ou se o jogador tem <6 anos). Regra de idade explícita: menor de 18 só conhece menores; adulto só adultos; diferença dentro do limite das amizades. Evento na biografia dos dois.
- Sorteio local; `game.rng` restaurado (o mundo simulado não muda). Sem novo schema de save. 275 testes OK; versionCode 1500300.
- Não feito (resto da G3): família/escola/trabalho do conhecido, conversar/convidar/aprofundar, namoro, app de relacionamentos, memória do relacionamento.

## 0.15.2 — G2b: área de estudo (2026-11-24)
- O jogador escolhe: ao tocar em "Estudar" no botão Foco, a área: Geral, Linguagens, Humanas, Natureza ou Matemática (o botão mostra "Foco: Estudar (Matemática)").
- Consequência: com área, o ganho mensal de cognição (25%/mês, +1) vai sempre para a habilidade da área (Linguagens→compreensão verbal, Humanas→memória, Natureza→aprendizagem, Matemática→raciocínio lógico); "Geral" mantém o sorteio entre as 4 (20%). Notas e custo de saúde iguais ao foco estudar.
- Áreas = as 4 do ENEM, ainda PROPOSTA (o dono não confirmou); trocar é editar a tabela `AREAS` em `sim/foco.py`.
- Save: chave opcional `area` em `meta` (sem novo schema; saves antigos abrem como "Geral"). Mundo simulado idêntico (gerador local). 273 testes OK; versionCode 1500200.

## 0.14.4 — 2026-11-23 (somente documentação)
Nenhum código de jogo mudou (só o número da versão).
- Novo: `DIRECAO.md` — diagnóstico (o jogador ainda não toma decisões; o mundo só tem as pessoas criadas no início e nos nascimentos), requisitos do dono do projeto (R1–R5) e a trilha de jogabilidade G1–G4 em ordem.
- Alterado: `ROADMAP.md` (aviso de prioridade no topo) e `PROJECT_STATE.md` (a próxima atualização recomendada passa a ser G1, eventos com 3 opções).
- Regra nova: todo sistema futuro registra no CHANGELOG o que o jogador pode escolher nele e qual a consequência.

## 0.14.3 — 2026-11-23
Micro update: revisão visual dos 18 painéis (capturas conferidas uma a uma) e correções de acabamento. Regras, saves e RNG intactos; só textos de exibição mudaram no motor.
- Corrigido (`sim/views.py`, `sim/work.py`): durações apareciam como "12 ano(s) e 6 mês(es)"; agora "12 anos e 6 meses" (singular/plural corretos: "1 ano e 1 mês").
- Corrigido (`web/css/app.css`): na barra com nota longa (Trabalho › Aptidão) o rótulo e o valor ficavam colados ("profissional54"); agora quebram linha com espaço.
- Corrigido (`web/css/app.css`, `web/js/panels.js`): o título "Panorama econômico" encostava nas bordas da faixa; títulos com mais de 14 caracteres encolhem.
- Corrigido (`sim/panels.py`): o botão "Salvar automaticamente: ligado" vazava para fora do botão (a arte do kit não estica); o rótulo agora é "Autosave: ligado/desligado". Decimais do Panorama (índice do clima, Gini) em vírgula, como o resto.
- Conferido sem mudança: ficha, escola, bens, relações, saúde, bem-estar, mente, social, família, árvore, biografia, empresas, impostos, proteção e personagens.

## 0.14.2 — 2026-11-23
Micro update: correções da tela de morte COM herdeiros (achadas ao conferir as capturas que faltavam). Motor, regras, saves e RNG intactos.
- Corrigido (`web/js/app.js`): ao escolher um herdeiro em "Continuar a história como…", o personagem trocava mas o diálogo "In memoriam" continuava aberto por cima do jogo; agora fecha.
- Corrigido (`web/css/app.css`): o rótulo de parentesco (Esposa/Filho/Filha) ficava ouro-claro sobre pergaminho claro, quase invisível, no diálogo de luto; agora usa o vinho.
- Novo: `tests/e2e_morte_herdeiros.py` (opcional, Playwright): família pronta, joga com o mais velho até morrer, confere lista de herdeiros, botões, troca de personagem e que o diálogo fecha.
- Verificado: captura da morte com herdeiros e do jogo após continuar conferidas visualmente; e2e sem erro de JavaScript.

## 0.14.1 — 2026-11-23
Micro update: tela de morte sem herdeiros e regressão completa da interface gráfica. Motor, regras, saves e RNG intactos.
- Alterado (`web/js/app.js`): quando o jogador morre e não há parentes vivos, a tela "In memoriam" agora tem os botões **Novo personagem** (abre o painel Personagens), **Voltar ao título**, Ver biografia e Fechar (antes só havia texto mandando procurar em Menu › Ajustes › Personagens).
- Corrigido (testes): os 4 testes de `TestCLI` chamavam `main.py` sem `--cli`; desde a 0.14.0 isso sobe o servidor web e os testes estouravam o tempo limite. Agora passam `--cli`. Nenhum código do jogo mudou por causa disso.
- Novo: `tests/e2e_morte.py` (opcional, Playwright): leva um personagem de 108 anos até a morte e confere os 4 botões, o painel Personagens e a volta ao título.
- Verificado: suíte completa `python3 -m unittest discover -s tests -t .` = 256 testes (231 antigos + 25 da 0.14.0), todos passando (~70 s).

## 0.13.0 — 2026-11-22
Macroeconomia e família trabalhadora (Fases 5/6). Atualização grande: 4 sistemas novos, 1 módulo (`sim/macro.py`). Esquema de save v14 (v1–v13 legíveis). Interruptores: `macro.ATIVO`, `economy.IMPOSTOS`, `economy.PENSAO`, `engine.LICENCA`.
- Novo — inflação e salário mínimo dinâmico (`sim/macro.py`): taxa anual determinística por (semente, ano) ligada ao ciclo (4,5% + 2 pp × índice + ruído, entre 1% e 12%); índice de preços mensal; mínimo reajustado só em janeiro (inflação do ano anterior + 1–2% de ganho real). `economy.monthly_salary`, `pension`, `unemployment_benefit` e `current_income` ganharam o parâmetro opcional `mw` (padrão = mínimo-base: chamadas antigas inalteradas); auxílio social e faixas escalam com o mínimo; custo de vida escala com os preços; patrimônio rende taxa real + inflação; teto da dívida acompanha os preços. Sem `game.rng`.
- Novo — impostos e orçamento do Estado: `economy.income_tax` (previdência 8% até 6 mínimos + IR progressivo; só formais não aposentados); o saldo mensal do domicílio desconta o imposto (`h["imposto"]`); `game.macro` guarda receita/despesa do ano corrente e do anterior e o caixa acumulado (receita = impostos; despesa = aposentadorias, seguro, assistência, licenças, auxílio). Panorama econômico mostra inflação, índice de preços, mínimo (nominal e real) e Estado.
- Novo — pensão alimentícia (`economy.alimony_flows`): genitor sem a guarda repassa 15% da renda (+5% por filho adicional, teto 30%) ao guardião; ajusta a renda dos dois domicílios; ausente se o pagador não tem renda, o guardião morreu, o casal voltou a viver junto ou o filho tem 18 anos.
- Novo — licença-maternidade (`engine._maternity`, `Character.leave_until`): 4 meses de licença paga para mãe formal; estabilidade na gestação e na licença; 6% das formais e 25% das informais deixam o emprego e não procuram trabalho por 12 meses; ficha da CLI mostra o afastamento. Usa gerador local do parto (não consome `game.rng`).
- Alterado: `_work` ganha a proteção/afastamento (uma rolagem de demissão continua sendo consumida em todos os casos); `_tick` chama `macro.tick` antes do trabalho e da economia; CLI: finanças mostram impostos, pensão paga/recebida e saldo após impostos; "reais correntes".
- Persistência: coluna `leave_until` (v14) e chave `macro` em `meta`; v13 e anteriores carregam com preços 1,0, mínimo R$ 1.500 e Estado zerado.
- Medido (20 anos, 3 sementes, ~125 pessoas): preços ×2,17–2,45, mínimo real 1,23–1,25×, emprego 25–54 anos 73–91% (população pequena), 9–17 licenças e 0–1 saídas por simulação; caixa do Estado oscila (déficit anual em todas as sementes: aposentadorias sem contribuição prévia).
- Testes: +27 (231 no total, todos passando): `TestMacro` (8), `TestImpostosEEstado` (4), `TestPensaoAlimenticia` (4), `TestLicencaMaternidade` (7), `TestIntegracaoV013` (3, tudo ligado: determinismo, "carregar e continuar == não parar", CLI). Os 204 testes anteriores rodam com as novidades DESLIGADAS por padrão (cabeçalho de `tests/test_core.py`) para preservar as calibrações; as classes novas ligam tudo via mixin `NovidadesV013`. Verificado por mutação: remover a estabilidade, o escalonamento do custo pelos preços, o débito da pensão, o reajuste do mínimo ou o desconto do imposto faz testes falharem.
- ATENÇÃO: com as novidades ligadas (padrão do jogo) o fluxo do RNG principal muda (dispensa de gestantes) e os valores em reais passam a ser correntes: o mínimo e os preços sobem com o tempo. Saves antigos divergem a partir do ponto carregado.
- Limitações: inflação exógena; orçamento do Estado sem retroalimentação; imposto só sobre salário (sem patrimônio/consumo); licença só com gestação ligada e só para a mãe; pensão sem decisão judicial; sem crédito, juros básicos nem câmbio.

## 0.12.0 — 2026-11-22
Gestação (Fase 2). Esquema de save v13 (v1–v12 legíveis). Interruptor `engine.GESTACAO`.
- Novo — gestação (`engine._conceive`, `_pregnancy_step`): o sorteio mensal que antes gerava o nascimento agora gera a CONCEPÇÃO (`conception_monthly` = taxa de nascimentos ÷ (1 − perda gestacional), para manter os nascimentos por mulher). A mãe fica grávida por 9 meses (`pregnant_until`, `pregnancy_father_id`); eventos `gravidez` ("Engravidou de … (parto previsto: mês/ano)") para mãe e pai. Grávida não engravida de novo; o intervalo mínimo de 15 meses entre partos passa a valer como parto anterior → concepção ≥6 meses.
- Novo — perda gestacional: 8% das gestações terminam no 3º mês (evento `gravidez` "perda gestacional").
- Parto: no mês previsto, nasce o bebê (herança de traços como antes); gêmeos (1,2%) e mortalidade materna passam a usar gerador local por (semente, mês, mãe) — só a criação do bebê consome `game.rng`. Pai que morreu durante a gestação: o bebê nasce com o sobrenome e o `father_id` dele, sem evento para o pai falecido. Morte da mãe encerra a gestação. Divórcio não cancela a gestação.
- Persistência: colunas `pregnant_until`, `pregnancy_father_id` (v13); saves v12 e anteriores carregam sem gestação em curso.
- CLI: ficha mostra "Gestação: parto previsto em mês/ano".
- Medido (150 casais × 3 sementes, 25 anos, sem divórcio): 1,73 filho por mulher com parto imediato e 1,68 com gestação (−3%: gestações em curso no fim e mortes maternas).
- Testes: +10 (`TestGestacao`); mixins `SemDivorcio`/`SemCirculo` desligam a gestação (preservam as calibrações antigas). 3 testes estatísticos antigos ajustados por serem frágeis ao fluxo do RNG: `test_separacao_depende_da_conscienciosidade` (efeito direto 1,74 testado antes do tempo avançar com informal controlado; estatístico só >1,1×), `test_calibracao_geral` (informalidade pooled nas duas sementes: com ≈30 empregados uma semente deu 0 informais por acaso) e `test_gemeos_interruptor_e_taxa_realista` (mede a taxa de gêmeos sem gestação, porque o atraso de 9 meses reduz os partos no horizonte fixo).
- Limitações: sem gravidez fora do casamento, sem saúde/idade da mãe afetando a perda gestacional, sem licença-maternidade nem efeito no trabalho/renda; a gestação não é visível aos amigos/família na biografia deles.

## 0.11.0 — 2026-11-22
Namoro (Fase 2). Esquema de save v12 (v1–v11 legíveis). Novo módulo `sim/romance.py`, interruptor `romance.ATIVO`.
- Novo — casais: solteiros vivos com ≥16 anos, sem cônjuge ativo nem parceiro, iniciam namoro (anual-base 30% aos 16–24, 22% aos 25–34, 10% aos 35–49, 4% a partir de 50; ×0,6–1,4 pela extroversão). Parceiro escolhido no círculo social (amigos e amigos de amigos; 25% de chance de alguém de fora se o círculo não tem par compatível), ponderado pela afinidade; regras de `engine._can_marry` (sexos diferentes, sem parentesco próximo, diferença ≤10 anos, sem voltar com o ex) e, se algum tem <18, diferença ≤3 anos. Eventos `namoro`.
- Novo — término: anual-base 35% × (1,7 − afinidade) × neuroticismo do casal (0,7–1,3), ×0,5 após 24 meses. Evento `namoro_fim`; parceiro morto também encerra o vínculo (evento `namoro_fim`).
- Novo — pedido de casamento: após ≥6 meses e ambos ≥18, anual 6% (18–21), 13% (22–39), 5% (40–49), 2% (50+); chama `engine._marry`. Os namorados saem do sorteio antigo de casamento (`engine._marriages`).
- Sem `game.rng`: gerador local por (semente, mês, sal, id) → o fluxo do RNG principal não muda; salvar/carregar/continuar é idêntico (testado).
- Persistência: colunas `partner_id`, `partner_since` (v12); saves v11 e anteriores carregam sem namoro.
- CLI: ficha mostra "Namoro: Fulano (há N meses)".
- Medido (300 adultos de 20–29 anos, 10 anos, 2 sementes): casamentos 98 e 85 (sem namoro: 83 e 86); 422–512 namoros iniciados e 262–326 términos. A fração de personagens originais com cônjuge no fim ficou em 54–63% (sem namoro: 51%): namoro puxa um pouco para cima; calibração não refeita.
- Testes: +10 (`TestNamoro`); mixins `SemDivorcio`/`SemCirculo` desligam o namoro para preservar as calibrações antigas; 1 teste estatístico antigo (`test_separacao_depende_da_conscienciosidade`) teve o limite relaxado de 1,4 para 1,25 (a razão observada já era ≈1,40, na margem; mudar o fluxo do RNG o derrubou por 123 contra 123,2).
- Limitações: sem coabitação, sem ciúme/traição, sem namoro do mesmo sexo, sem memória de convivência; solteiros com namoro não participam do sorteio de casamento antigo (o que muda a calibração de casamentos).

## 0.10.0 — 2026-11-22
Atualização grande da Fase 2 (vida social/família). Esquema de save v11 (v1–v10 legíveis).
- Novo — fim de amizades (`engine._friendship_drift`, `drift_monthly`, interruptor `FIM_AMIZADES`): cada amizade entre dois vivos tem chance anual-base de 5% de esfriar, × (1,7 − afinidade), ×1,5 se a diferença de idade passou do limite, ×0,4 entre colegas de escola/trabalho, ×0,5 em amizades com ≥5 anos. Evento `amizade_fim` para os dois; `Game.remove_friendship`. Abre vagas no círculo (máx. 8 amigos). Amigos mortos permanecem registrados (memória).
- Novo — gêmeos (`GEMEOS`, `GEMEOS_CHANCE` = 1,2% dos partos): segundo filho no mesmo parto, respeitando `MAX_FILHOS`; evento `gemeos` para os pais; um único teste de mortalidade materna por parto.
- Novo — guarda dos filhos (`engine._custody`, interruptor `GUARDA`): no divórcio, os filhos comuns <18 ficam com a mãe (≈73–88%) ou o pai (12% + até 30% conforme sua fatia da renda do casal, teto 60%); eventos `guarda` (filhos e pais). `Character.guardian_id`; `economy._payer` prioriza o guardião vivo, depois mãe, depois pai (domicílio e custo seguem a guarda). Ficha da CLI mostra "Guarda".
- Persistência: coluna `guardian_id` (v11); saves v10 e anteriores carregam com guarda indefinida (comportamento antigo).
- Testes: +11 (`TestV0100`); 2 ajustados (contagem de eventos de amizade agora desconta `amizade_fim`; teste de colegas mede a formação com o fim de amizades desligado).
- Limitações: amizade desfeita pode se refazer depois; sem inimizade/namoro; guarda sem disputa judicial nem pensão; guarda não muda se o guardião casa de novo ou o filho cresce (só vale <18).

## 0.9.2 — 2026-11-22
Prêmio salarial por porte da empresa (Fase 6). Sem mudança de esquema de save.
- Alterado (`sim/economy.py`): `monthly_salary(c, firm=None)` e `pension(c, firm=None)` aplicam `FATOR_PORTE` (micro 0,90 / pequena 0,97 / média 1,06 / grande 1,14; ILUSTRATIVO). Sem empresa ou com `economy.PREMIO_PORTE = False`, o fator é 1 (comportamento da 0.8.0). `current_income` e `apply_month` usam a empresa do vínculo (`_firm_of`).
- Alterado (`sim/engine.py`): evento de promoção e cálculo da aposentadoria usam a empresa do vínculo (a aposentadoria é calculada antes de zerar `workplace`).
- Medido (3 sementes, 45 famílias, 12 anos): renda média dos empregados ≈2,44 mínimos com prêmio contra ≈2,29 sem (≈+6,6%).
- Testes: +6 (`TestPremioPorte`), valores literais (ex.: professor 4500 → grande 5130, micro 4050; promoção a pleno em empresa média = R$ 5.962,50). Um bug real foi achado pelo teste: o texto da promoção ignorava o prêmio.
- Limitações: salário depende só do porte (não do setor nem da empresa); sem negociação salarial.

## 0.9.1 — 2026-11-22
Seguro-desemprego (Fase 6). Esquema de save v10.
- Adicionado (`sim/economy.py`): `unemployment_benefit`, `grant_unemployment`, `receiving_unemployment`. Elegível: demissão involuntária (perda de emprego sorteada ou fechamento da empresa) de vínculo FORMAL com ≥12 meses. Valor = 60% do último salário (com prêmio de porte), piso 1 e teto 2 salários mínimos; 4 parcelas (12–23 meses de vínculo) ou 5 (≥24). Evento `trabalho` "Passou a receber seguro-desemprego…". Interruptor `economy.SEGURO_ATIVO`. Sem `game.rng`.
- Alterado: `engine._work` e `firms.close_firm` concedem o benefício ANTES de `work.clear_job`; `work.start_job` e a aposentadoria encerram o benefício; `economy.apply_month` zera parcelas esgotadas e `current_income(c, age, now, firm)` paga o benefício enquanto durar.
- Alterado (`sim/models.py`, `sim/persistence.py`): `unemp_until`, `unemp_amount`; `SCHEMA_VERSION` 9 → 10 (2 colunas no fim de `characters`); v1–v9 legíveis, sem benefício em curso.
- Alterado (`sim/ui_cli.py`): ficha mostra "Seguro-desemprego: R$ …/mês (última parcela em MM/AAAA)"; panorama mostra quantos recebem.
- Testes: +14 (`TestSeguroDesemprego`): valores literais (professor em empresa média: R$ 2.862,00), piso, teto, não elegíveis, fechamento, demissão pelo motor, fim das parcelas, save v10 e v9. Verificado por mutação (8 mutantes do conjunto 0.9.0–0.9.2 detectados).
- Corrigido durante o desenvolvimento: ao inserir a leitura das colunas novas no loader, o `else` da leitura v8 passou a pertencer ao `if` novo, o que reexecutaria a inferência de economia por cima de saves v8/v9. Um teste antigo (v7) acusou; o teste v9 foi reforçado para exigir renda, patrimônio e empresa preservados.
- Limitações: benefício não tem fonte de financiamento nem imposto; sem exigência de busca ativa; só uma concessão por vínculo; sem seguro para quem pede demissão.

## 0.9.0 — 2026-11-22
Ciclo econômico (Fase 6). Sem mudança de esquema de save.
- Adicionado (`sim/cycle.py`, novo): índice anual AR(1) (persistência 0,55, ruído 0,5, truncado em ±1, ano-base 1990) determinístico por semente e ano, sem `game.rng` e sem nada a salvar. Rótulos: recessão (≤ −0,45), estabilidade, expansão (≥ +0,45). Interruptor `cycle.ATIVO`.
- Alterado (`sim/engine._work`): contratação × (1 + 0,45·índice) e demissão × (1 − 0,50·índice), mantendo um sorteio por decisão (o fluxo do RNG não muda).
- Alterado (`sim/firms.yearly`): risco de fechamento × (1 − 0,80·índice) e vacância-alvo × (1 + 0,50·índice).
- Alterado (`sim/economy.summary`, `ui_cli.show_economy`): "Clima econômico: … (índice …)".
- Medido (3 sementes, 45 famílias, 12 anos): emprego de 25–54 anos ≈87,7% com ciclo e ≈87,2% sem; desvio anual 4,7 contra 3,5 pontos percentuais; correlação índice × emprego só ≈0,33 (efeito real, mas ruidoso em populações pequenas).
- Testes: +9 (`TestCicloEconomico`). `TestTrabalho` passou a rodar com o ciclo desligado: ele isola o efeito da conscienciosidade na perda de emprego, e o ciclo (desemprego mais longo) comprime a razão baixa/alta (1,31–2,14 em 6 sementes, ainda >1; o limiar 1,4 já era marginal na 0.8.0, mínimo 1,30). Teste de versão do save passou a usar `SCHEMA_VERSION`.
- Limitações: ciclo é exógeno e anual (sem inflação, sem choque setorial, sem efeito sobre salários nem sobre fundação além da vacância); um índice por partida, igual para todos.

## 0.8.0 — 2026-11-22
Empresas e vagas (Fases 5/7): o "local de trabalho" numérico vira empresa genérica com número limitado de vagas por ocupação; contratação depende de vaga; empresas fecham e são fundadas. Esquema de save v9.
- Adicionado (`sim/models.py`): `Firm` (id, nome genérico "Empresa 007", setor, porte, fundação, fechamento, `slots` = vagas por ocupação); `Game.firms` e `Game.next_firm_id`. `Character.workplace` passa a ser o id da empresa.
- Adicionado (`sim/firms.py`, novo; sem `game.rng`, usa gerador local da semente): 7 setores genéricos (cada uma das 19 ocupações pertence a ao menos um) e 4 portes (micro, pequena, média, grande; vagas, risco anual de fechar e fator de informalidade próprios). Mundo inicial de 24 empresas, criado sob demanda e de forma determinística.
- Alterado (`sim/engine._work`): contratação e troca de ocupação só sorteiam ocupações com vaga livre em alguma empresa aberta (`firms.open_occupations`); sem vaga compatível o desempregado segue procurando. Em janeiro roda `firms.yearly`: (1) empresas fecham com risco por porte (micro 4%/ano … grande 0,5%), demitindo todos (evento `trabalho`, passam a procurar emprego); (2) o mercado enxuga vagas excedentes (acima de ≈2,5× o desejado) e dissolve empresas vazias; (3) repõe vagas até a vacância-alvo de 12% por ocupação, expandindo empresas ou fundando novas. Nunca fecha abaixo de 5 empresas abertas.
- Alterado (`sim/work.start_job`, `sim/economy.initial_economy`): escolhe a empresa (sorteio ponderado pelas vagas livres); sem vaga livre (colocação inicial, saves antigos, chamada direta) amplia uma empresa do setor ou funda uma microempresa. A chance de vínculo informal passa a depender do porte (micro ×1,5, pequena ×1,1, média ×0,8, grande ×0,5; teto 95%). Colegas de trabalho = mesma empresa.
- Alterado (`sim/persistence.py`): `SCHEMA_VERSION` 8 → 9 (tabela `firms`, `next_firm_id` em `meta`); v1–v8 legíveis: empresas são criadas e todos os empregados realocados na carga (`firms.reconcile(force=True)`, sem `game.rng`), gravadas no próximo salvamento.
- Alterado (`sim/ui_cli.py`): ficha mostra "Empresa 007 (setor, porte)"; nova opção 14 "Empresas e vagas" (abertas/fechadas, vagas ocupadas/livres, vacância e as 15 maiores); Panorama econômico mostra empresas e vagas livres. `sim/__init__.__version__` estava defasado em "0.1.2" e foi corrigido.
- Interruptor `firms.ATIVO` (padrão True; False = comportamento da v0.7.0, local 0–24 sem vagas).
- Medido (ilustrativo): emprego de 25–54 anos ≈84–87% (faixa por ano 68–96% em populações pequenas; antes 83–94%); vacância média ≈67% com 12 famílias, ≈44% com 40 famílias e ≈22% com ~800 pessoas (150 famílias, 46 empresas). Empresas abertas mantêm-se estáveis ao longo de 12–15 anos.
- Corrigido durante o desenvolvimento (achados por medição, não por teste): na primeira versão o mercado nunca ficava apertado (vacância ≈80% com 300 pessoas) e o número de empresas caía de 25 para 15 em 15 anos, porque fechamentos não eram repostos; o enxugamento anual de vagas excedentes e a dissolução de empresas vazias resolveram os dois.
- Testes: +13 (`TestEmpresas`); total 145, todos passando (~67 s). Dois testes antigos foram ajustados porque verificavam invariantes superadas (versão do save = 8; local de trabalho entre 0 e 24); `snapshot` agora inclui as empresas. Verificado por mutação: ignorar o filtro de vagas na escolha da ocupação faz `test_sem_vagas_ninguem_e_contratado` falhar.
- Limitações: em populações pequenas (dezenas de trabalhadores) as vagas quase nunca pesam (piso de vagas livres por ocupação); salário não depende do porte nem da empresa; empresas não têm produtividade, hierarquia, nome real nem processo seletivo; fechamento e fundação são sorteios independentes da economia (sem ciclo econômico); "fechadas" inclui as dissolvidas por falta de vagas e empregados; sem migração entre cidades.

## 0.7.0 — 2026-11-22
Economia e carreira (Fases 5/6): salário, renda, patrimônio, domicílio, promoção, informalidade, colegas de trabalho, herança e panorama econômico. Esquema de save v8.
- Adicionado (`sim/economy.py`, novo; sem `game.rng`): salário mensal = base da ocupação (em salários mínimos; mínimo ilustrativo R$ 1.500) × nível da carreira (júnior 1,0 / pleno 1,25 / sênior 1,6 / chefia 2,2) × experiência (+2%/ano, teto +40%) × 0,8 se informal. Valores ILUSTRATIVOS, em reais constantes (sem inflação).
- Adicionado: aposentadoria com renda (formal = 70% do último salário, mín. 1 e teto 10 salários mínimos; informal/sem ocupação = 1 mínimo); benefício assistencial de 1 mínimo para quem tem ≥65 anos, não trabalha e não é aposentado.
- Adicionado: domicílios (`build_households`): adultos + cônjuge ativo + dependentes (menores de 18, e jovens solteiros <25 sem renda, sustentados pela mãe viva ou, na falta, pelo pai; sem guarda, o filho fica com a mãe). Custo de vida mensal 0,9 mínimo (1º adulto) + 0,6 (2º adulto) + 0,45 por dependente; menor órfão não gera custo (parentes/Estado). Auxílio social ilustrativo (0,225 mínimo por dependente) quando a renda per capita é <0,6 mínimo.
- Adicionado (`economy.apply_month`, chamado após `_work`): renda do mês (salário, benefício ou 0), experiência +1 mês por mês empregado; saldo do domicílio dividido igualmente entre os adultos; saldo positivo poupado em 15–40% (sobe com a conscienciosidade), déficit integral; rendimento de 0,4%/mês sobre patrimônio positivo, juros de 1%/mês sobre dívida; dívida limitada a 24 mínimos.
- Adicionado: herança na morte (`economy.inherit`, chamada em `engine._die`): cônjuge ativo e filhos vivos (metade/metade; só um grupo = tudo); sem herdeiros o patrimônio vai ao Estado; dívida se extingue; evento `heranca` para cada herdeiro.
- Adicionado (`sim/work.py`): carreira — `rank` (0–3), `promotion_monthly` (só formais, <60 anos, ≥24 meses no nível, ×aptidão, última etapa ×0,5, saúde <30 ×0,3), `start_job`/`clear_job` (vínculo formal/informal por nível da ocupação: 45%/20%/8%/3%; local de trabalho nº 0–24); informal perde o emprego 1,5× mais. Evento "Foi promovido(a) a … novo salário: R$ …". Aleatoriedade de carreira vem de `work.local_rng` (semente+personagem+mês+sal), NÃO de `game.rng`: o fluxo do RNG principal não muda e carregar e continuar segue idêntico.
- Adicionado (`sim/engine.py`): colegas de trabalho (mesmo local, ambos empregados) pesam ×3 (`FATOR_COLEGAS_TRABALHO`) na escolha de amigos (`friend_weight`, que também reúne afinidade e colegas de escola); aposentadoria define a renda do benefício; interruptor `engine.ECONOMIA` (padrão True; False = v0.6.0).
- Adicionado (`sim/models.py`): `rank`, `rank_since`, `informal`, `workplace`, `experience`, `income`, `wealth`.
- Adicionado (`sim/factory.py`): `economy.initial_economy` na criação (carreira, renda e patrimônio iniciais; determinístico, sem `game.rng`; patrimônio só ≥18 anos).
- Alterado (`sim/persistence.py`): `SCHEMA_VERSION` 7 → 8 (7 colunas no fim de `characters`); v1–v7 legíveis, economia inferida na carga (sem RNG) e gravada no próximo salvamento.
- Alterado (`sim/ui_cli.py`): ficha mostra nível e vínculo (formal/informal), "Renda … | Patrimônio … | Local de trabalho nº"; opção 12 "Finanças" (domicílio: renda, custo, auxílio, saldo e patrimônio de cada adulto); opção 13 "Panorama econômico" (renda média/mediana, Gini, patrimônio, empregados/informais/procurando, renda por escolaridade); eventos `heranca` só do jogador no relatório de avanço.
- Medido (25 famílias, 12 anos, 3 sementes): renda média dos empregados ≈2,1–2,3 mínimos; Gini da renda ≈0,33–0,37; informais ≈11–12% dos empregados; endividados 4–11% dos adultos (eram 30–43% antes de jovens sem renda virarem dependentes e do auxílio social); formação maior rende mais. Valores ILUSTRATIVOS.
- Testes: +26 (`TestEconomia` 25 + CLI 1); total 132, todos passando (~55 s). Verificado por mutação (6 mutantes): informal sem desconto, informal promovido, herança do cônjuge errada, dependentes sem custo, colegas sem peso e dívida sem teto fazem testes falharem (o mutante "dependentes sem custo" sobreviveu na primeira versão e o teste foi reforçado com valor literal). Os mixins `SemDivorcio` e `SemCirculo` também desligam `ECONOMIA`; `snapshot` inclui os campos novos.
- Observação: como a carreira usa gerador local, partidas da v0.6.0 continuam com o mesmo fluxo de `game.rng`; mudam apenas por efeitos reais (informalidade eleva separações; colegas alteram o desfecho das amizades).
- Limitações: sem inflação, impostos, empresas e vagas concretas (local de trabalho é só um número), seguro-desemprego, guarda dos filhos (filhos sempre com a mãe), trabalho de meio período, empreendedorismo, crédito/imóveis, diferença salarial por sexo ou região; custo de vida e auxílio são fixos; herança não considera pais/irmãos nem testamento.

## 0.6.0 — 2026-11-22
Trabalho (Fase 5, primeira microatualização): primeiro emprego, ocupação por formação e aptidão, desemprego, mudança de ocupação e aposentadoria. Esquema de save v7.
- Adicionado (`sim/work.py`, novo, sem dependência do motor): tabela de 19 ocupações genéricas em 4 níveis (qualquer escolaridade / fundamental / médio / superior completo), cada uma com aptidão mínima e peso; `education_level`, `work_aptitude` (60% cognição média dos 8 domínios + 40% conscienciosidade), `pick_occupation`, `hire_monthly`, `separation_monthly`, `retirement_monthly`, `job_change_monthly`, `default_work`, `work_label`. Sem empresas, instituições ou salários (Fases 5/6 seguintes).
- Adicionado (`sim/engine.py`): `_work`, depois da escola e antes das amizades. Por mês, em ordem de id: aposentadoria (60+: 0,8%/mês até 64, 3% até 69, 6% até 74, 100% aos 75+; quem estuda não se aposenta); perda de emprego (base 1,2%/mês, ×1,5 nos 12 primeiros meses de vínculo, ×0,7 após 60, ×(1,3−0,6·consc/100), ×(1+ (50−saúde)/50) se saúde baixa); mudança para ocupação de nível maior quando a formação superou a da ocupação (0,6%/mês, abaixo de 60 anos); entrada no mercado (≥16 anos, fora da escola/faculdade → "Passou a procurar trabalho") e contratação (base 12%/mês × (0,5+0,5·fator de aptidão); ×0,6 aos 16–17, ×0,7 aos 50–59, ×0,4 aos 60+; saúde <30 não é contratada). Estudantes não procuram emprego; quem já trabalha continua empregado ao estudar.
- Formação importa, mas não garante: a ocupação sorteada exige escolaridade e aptidão mínimas; ocupações de nível abaixo da formação têm peso ×0,2 (não zero). Medido (3 sementes, 300 pessoas de 28 anos, 5 anos): graduados em vaga de nível superior 42–48% (média de nível 1,9–2,0); concluintes do médio 0% (média 1,65–1,70).
- Adicionado: eventos `trabalho` (procura, primeiro emprego, emprego, perda, mudança de ocupação, aposentadoria); `work_label` na ficha da CLI ("Trabalho: …", só a partir de 16 anos); relatório de avanço mostra eventos `trabalho` só do jogador (como `escola` e `amizade`); categoria na dica da biografia.
- Adicionado (`sim/models.py`): `occupation`, `job_start`, `seeking_since` (mês absoluto = ano·12+mês), `retired`, `jobs_held`.
- Adicionado (`sim/factory.py`): `create_character` chama `work.default_work`: situação inicial de quem entra com ≥16 anos e fora da escola (≥60 anos pode já estar aposentado; senão 88% empregados, o resto procurando). Determinística e SEM usar `game.rng` (gerador local da semente+id), então a criação de personagens não muda o RNG.
- Alterado (`sim/persistence.py`): `SCHEMA_VERSION` 6 → 7 (5 colunas no fim de `characters`). v1–v6 legíveis; a situação de trabalho é inferida na carga com `default_work` (sem RNG) e gravada no próximo salvamento.
- Adicionado: interruptor `engine.TRABALHO` (padrão True); desligado = comportamento da v0.5.0 (sem eventos de trabalho).
- Medido (simulação completa, 40 famílias, 10–30 anos, 3 sementes; população 25–54 anos): empregados 83–94%; desempregados 6–17% da força de trabalho (população pequena, ruído alto). Valores ILUSTRATIVOS.
- Testes: +17 (`TestTrabalho` 16 + CLI 1); total 106, todos passando (~50 s). Verificado por mutação: ocupação sem exigir formação, aptidão sem efeito na contratação, conscienciosidade sem efeito na perda de emprego, saúde ignorada na contratação, aposentado que volta a trabalhar e estudante que procura emprego fazem testes falharem. Durante o desenvolvimento, um limiar de teste (troca de ocupação ≥30%) estava errado (taxa projetada ≈18% em 36 meses) e foi corrigido no teste, não no código.
- Alterado (testes): os mixins `SemDivorcio` e `SemCirculo` também desligam `TRABALHO`; `snapshot` inclui os campos de trabalho. Sem isso, `TestNascimentos` falhava por mudança no consumo de RNG.
- ATENÇÃO (esperado): com o trabalho ligado muda o consumo de RNG; partidas salvas antes divergem a partir do ponto carregado. Determinismo por semente e "carregar e continuar == não parar" valem (testado).
- Limitações: sem salário, empresas, vagas limitadas, setor formal/informal, concursos, desemprego por região nem ciclo econômico (taxas fixas); sem diferença por sexo ou filhos pequenos na participação; adultos desempregados nunca saem da força de trabalho (só se aposentam); sem experiência acumulada ou promoção dentro da ocupação; formação em curso/área ainda não conta (só o nível); estudantes não procuram emprego (sem trabalho de meio período); aposentadoria sem renda (Fase 6); trabalho ainda não afeta saúde, casamento nem amizades (sem colegas de trabalho).

## 0.5.0 — 2026-11-21
Ensino superior e retorno aos estudos (Fase 3). Esquema de save v6.
- Adicionado (`sim/engine.py`): em fevereiro, `_enroll_college` (quem concluiu o médio, ≥17 anos, sem curso superior, ingressa com chance anual-base por idade — `INGRESSO_SUPERIOR`: 17% até 20 anos, 6% até 24, 2% até 34 — multiplicada pela aptidão: `aptitude` = 60% cognição média + 40% conscienciosidade; fator `(aptidão−30)/30` limitado a 0,1–2,0) e `_return_to_school` (quem parou entre 5 e 11 anos de estudo, com 18–45 anos, volta com 2,5% ao ano × fator de aptidão; evento "Voltou a estudar"). Em dezembro, `_close_college_year`: nota ≥50 aprova; reprovado repete o ano; abandono `college_dropout_probability` (base 7%, sobe com nota baixa, ×2 se reprovou); 4 anos = "Formou-se no ensino superior".
- Retorno: estudantes que voltaram não são desligados aos 20 anos e têm abandono ×1,5 (`FATOR_ABANDONO_RETORNO`).
- Adicionado: colegas de curso superior (ambos cursando, diferença ≤4 anos) valem como colegas nas amizades; `education_label` cobre cursando / incompleto / completo no superior; morte encerra o curso; eventos na categoria `escola`.
- Adicionado (`sim/models.py`): `returned_to_school`, `higher_years`, `in_college`, `graduated`.
- Alterado (`sim/persistence.py`): `SCHEMA_VERSION` 5 → 6 (4 colunas no fim de `characters`); v1–v5 legíveis (sem ensino superior).
- Alterado (`sim/ui_cli.py`): desempenho do último ano também aparece para quem cursa o superior.
- Adicionado: interruptor `engine.ENSINO_SUPERIOR` (padrão True); desligado = comportamento da v0.4.0.
- Medido (3 sementes, 500 crianças de 6 anos, 24 anos simulados): médio 78–81%, ingressaram no superior 33–36%, formados 22–25%, retornaram aos estudos ≈3%. Valores ILUSTRATIVOS.
- Testes: +9 (`TestEnsinoSuperior`); total 89, todos passando (~29 s).
- ATENÇÃO (esperado): com o superior ligado muda o consumo de RNG; partidas salvas antes divergem a partir do ponto carregado. Determinismo por semente e "carregar e continuar == não parar" valem (testado).
- Limitações: adultos iniciais não nascem com superior; sem curso/área, instituição, custo nem renda; sem pós-graduação, EJA para quem nunca foi à escola nem retorno ao superior após abandono; formação ainda não afeta trabalho (Fase 5).

## 0.4.0 — 2026-11-21
Educação básica (Fase 3, primeira microatualização): matrícula, ano letivo, aprovação/reprovação, abandono e colegas de turma. Esquema de save v5.
- Adicionado (`sim/engine.py`): `_school`, depois dos nascimentos e antes das amizades. Em fevereiro, quem tem 6–14 anos, nunca foi matriculado e não abandonou é matriculado (98%; senão `dropped_out`). Em dezembro, cada aluno recebe desempenho 0–100 (`school_performance`): 55% cognição média de 5 domínios ajustada pela idade (atual ÷ fração de desenvolvimento), 30% conscienciosidade, 15% saúde, + ruído (sd 6). Nota ≥45 aprova (avança 1 ano); abaixo reprova. Depois, sorteio de abandono (`dropout_probability`: base 0,4% no fundamental e 3% no médio, ×(1 + (50 − nota)/20) para nota baixa, ×2,5 se reprovou). Aos 20 anos sem concluir o médio, encerra os estudos. Concluir 9 anos = fundamental; 12 = médio (para de estudar).
- Adicionado: `grade_label`, `education_label` (texto da série/escolaridade) e eventos `escola` (matrícula, aprovação, reprovação, conclusão, abandono).
- Adicionado: colegas de turma (ambos cursando e idades ≤1 ano de diferença) têm peso ×4 (`FATOR_COLEGAS`) na escolha de amigos.
- Adicionado (`sim/models.py`, `sim/factory.py`): campos `schooling_years`, `in_school`, `dropped_out`, `school_performance`; `factory.default_schooling` (sem RNG): crianças de 6–17 anos entram na série da idade; adultos recebem 12, 9 ou 5 anos conforme cognição média e conscienciosidade; morte encerra a matrícula.
- Alterado (`sim/persistence.py`): `SCHEMA_VERSION` 4 → 5 (4 colunas no fim de `characters`). v1–v4 legíveis; a escolaridade é inferida na carga (sem RNG) e gravada no próximo salvamento.
- Alterado (`sim/ui_cli.py`): ficha mostra "Escolaridade" (e o desempenho do último ano para quem estuda); o relatório de avanço mostra eventos `escola` só do jogador (como `amizade`).
- Adicionado: interruptor `engine.EDUCACAO` (padrão True); desligado = comportamento da v0.3.0 (sem eventos escolares nem peso de colegas).
- Medido (3 sementes, 600 crianças de 6 anos, 13 anos simulados): fundamental concluído por 91–93% dos vivos, médio 71–73%, abandono 11–14%, reprovação ≈6% das avaliações. Valores ILUSTRATIVOS, não estatística oficial.
- Testes: +13 (`TestEducacao`); total 80, todos passando. Verificado por mutação: sem peso de colegas, sem cognição no desempenho, reprovado que avança, abandono sem efeito do desempenho e matrícula antes dos 6 anos fazem testes falharem. Durante o desenvolvimento, o teste de colegas se mostrou fraco (não detectava a mutação) e foi reforçado (agrega 6 sementes; medido ≈1,8× com o fator e ≈1,07× sem).
- Testes legados rodam com `EDUCACAO` desligado (mixins `SemDivorcio` e `SemCirculo`).
- ATENÇÃO (esperado): com a educação ligada muda o consumo de RNG; partidas salvas antes divergem a partir do ponto carregado. Determinismo por semente e "carregar e continuar == não parar" valem.
- Limitações: sem instituições/escolas concretas nem turmas (colega = mesma faixa de idade cursando); sem retorno aos estudos após abandono, sem ensino superior, creche ou EJA; sem custo, renda familiar ou região; desempenho não muda com o tempo na escola nem afeta ainda trabalho, renda ou casamento (Fases 5–6); sem conhecimento por disciplina (Fase 4).

## 0.3.0 — 2026-11-21
Círculo social (Fase 2): amizades por afinidade e casamento dependente do círculo. Esquema de save v4.
- Adicionado (`sim/engine.py`): `_friendships`, executado depois dos nascimentos. Todo vivo com ≥6 anos e <8 amigos vivos sorteia 1 vez por mês (probabilidade anual base 50%, ×(0,4 + 1,2·extroversão/100)); se sair, escolhe um candidato ponderado por afinidade (`affinity`: proximidade de abertura, amabilidade e extroversão). Candidato: vivo, ≥6 anos, ainda não amigo, com vaga, sem parentesco próximo, diferença de idade ≤3 (mais novo <12), ≤6 (<18) ou ≤12 anos (limite pela idade do mais novo). Eventos `amizade` nos dois.
- Adicionado: `social_circle` (amigos e amigos de amigos vivos) e luto de amigo (`falecimento_amigo`) quando não há parentesco.
- Alterado (`_marriages`): o parceiro é escolhido entre os candidatos compatíveis do círculo social; se não há nenhum no círculo, há 40% de chance de conhecer alguém de fora (senão nada acontece). Antes: sorteio na população inteira.
- Adicionado: interruptor `engine.CIRCULO_SOCIAL` (padrão True). Desligado = comportamento da v0.2.0 (sem amizades, parceiro da população toda, mesmo consumo de RNG).
- Adicionado (`sim/models.py`): `Game.friendships`, `add_friendship`, `friend_ids`, `are_friends`.
- Alterado (`sim/persistence.py`): `SCHEMA_VERSION` 3 → 4 (nova tabela `friendships`). v1–v3 legíveis (sem amizades) e convertidos no próximo salvamento.
- Alterado (`sim/ui_cli.py`): ficha mostra "Amigos"; o relatório de avanço mostra amizades só do personagem do jogador (as demais continuam na biografia de cada um); categoria `amizade` na dica do filtro.
- Medido: 40 famílias, 30 anos (população ≈270): ≈7,6 amigos vivos por pessoa (máx. 8); 10 anos com 300 solteiros de 20–29: 56–58% casados com círculo vs 58–62% sem (faixa preservada); 30 anos em ≈0,5 s.
- Testes: +12 (`TestCirculoSocial`); total 67, todos passando. Verificado por mutação: casamento sem círculo, escolha sem afinidade, extroversão sem efeito e limite de idade removido fazem os testes falharem. Um teste novo revelou e corrigiu, ainda nesta versão, assimetria do limite de idade (usava a idade de quem toma a iniciativa).
- Testes legados (cônjuge, nascimentos, casamento) rodam com círculo e divórcio desligados (`SemDivorcio`); calibração roda sem círculo (`SemCirculo`) só por velocidade.
- ATENÇÃO (esperado): com o círculo ligado muda o consumo de RNG; partidas salvas antes divergem a partir do ponto carregado. Determinismo por semente e "carregar e continuar == não parar" valem.
- Limitações: amizades nunca terminam (só por morte) nem se aprofundam; sem inimizades, namoro nem colegas de escola/trabalho (virão com Fases 3 e 5); afinidade usa só 3 traços; limite fixo de 8 amigos; sem lugar/geografia.

## 0.2.0 — 2026-11-21
Atualização grande da Fase 2 (vida social): herança de traços, desenvolvimento cognitivo, divórcio, parentesco ampliado, mortalidade materna. Esquema de save v3.
- Adicionado (`sim/factory.py`): herança no nascimento. Personalidade = 50 + 0,4·(média dos pais − 50) + ruído (sd 14); potencial cognitivo idem com herdabilidade 0,5; limitado a 1–99. Medido (3000 bebês): correlação filho–pais ≈0,28–0,36; média ≈50 e desvio ≈14,7 preservados.
- Adicionado: `cognition_potential` (teto genético). A cognição atual = potencial × fração de desenvolvimento (35% ao nascer → 100% aos 18; `factory.cognition_development`). Cresce a cada aniversário até os 18 (`engine._develop_cognition`, sem RNG). Crianças avulsas também passam a ter cognição menor que adultos; adultos avulsos: cognição = potencial.
- Adicionado (`sim/engine.py`): divórcio (`_divorces`, entre nascimentos e casamentos). Risco anual base 1,4% por casal, modulado pela personalidade do casal (neuroticismo ↑, amabilidade ↓, conscienciosidade ↓) e ×1,5 se o mais novo tem <30 anos (multiplicador limitado a 0,3–3,0). Eventos `divorcio` nos dois e `divorcio_pais` nos filhos menores. Guarda `ex_spouse_id`; o ex não volta a casar com o ex; divorciados podem casar de novo; filhos mantêm os vínculos.
- Adicionado: mortalidade materna no parto (`maternal_death_risk`: ~0,08% <35 anos, 0,2% 35–39, 0,4% 40+, dobra com saúde baixa); evento de morte com causa e luto familiar.
- Alterado: `close_kin(a, b, game=None)` — com `game` bloqueia também avós/netos, tios/sobrinhos e primos de 1º grau (sem `game`, comportamento anterior).
- Alterado (`sim/persistence.py`): `SCHEMA_VERSION` 2 → 3 (colunas `cognition_potential` e `ex_spouse_id` no fim de `characters`). Leitura agora por nome de coluna; v1 e v2 continuam legíveis (potencial = cognição atual, ex = vazio) e são convertidos no próximo salvamento.
- Alterado (`sim/ui_cli.py`): ficha mostra estado civil (solteiro/casado/viúvo/divorciado), ex-cônjuge e cognição de crianças como atual/potencial; nova opção 11 "Família do personagem" (pais, avós, irmãos, cônjuge, filhos, netos).
- Testes: +18 (55 no total, todos passando). Verificado por mutação: herança zerada, divórcio desligado e parentesco ampliado desligado fazem os testes correspondentes falharem.
- ATENÇÃO (esperado): muda o consumo de RNG (herança, mortes no parto, divórcios) e a ordem de sorteio de personalidade/cognição na criação; partidas salvas antes divergem da evolução antiga a partir do ponto carregado. Determinismo por semente e "carregar e continuar == não parar" continuam valendo.
- Calibração: expectativa de vida simulada continua na faixa 73–77 (teste passa); nascimentos ≈1,5–2,3 filhos/mulher e casamento ≈45–75% em 10 anos continuam na faixa, medidos com divórcio desligado nesses testes (isolamento).
- Limitações: divórcio sem tempo de casamento nem motivo; sem custódia/guarda; sem uniões do mesmo sexo; sem gestação/gêmeos; personalidade ainda não muda com a idade nem com eventos; herança é aditiva simples (sem ambiente).

## 0.1.4 — 2026-11-21
Casamento durante a simulação (Fase 2).
- Adicionado (`sim/engine.py`): `_marriages`, executado ao fim de cada mês, depois dos nascimentos. Todo solteiro vivo com ≥18 anos, em ordem de id e ainda sem par no mês, sorteia 1 vez (`CASAMENTO`, probabilidade anual de iniciativa: 18–24: 4%, 25–29: 6%, 30–39: 3,5%, 40–59: 1,5%, 60+: 0,5%). Se sair, escolhe por sorteio um parceiro entre os solteiros compatíveis; sem compatível, nada acontece. Valores ilustrativos, não estatística oficial.
- Regras de compatibilidade: sexos diferentes; diferença de idade ≤ 10 anos; sem parentesco próximo (`close_kin`: pai/mãe-filho(a), irmãos e meio-irmãos). Tios/sobrinhos, avós/netos e primos ainda não são bloqueados.
- "Solteiro" = sem casamento ativo (`has_active_spouse`: vínculo mútuo com cônjuge vivo). Viúvos(as) podem casar de novo; o falecido mantém `spouse_id` como histórico. Vínculo unilateral conta como solteiro.
- Efeito: `spouse_id` mútuo + evento `casamento` ("Casou-se com X.") na biografia dos dois. Nomes e `family_id` não mudam. Filhos nascidos depois usam o cônjuge atual como pai/mãe (ciclo casamento → filhos funciona).
- Medido: ≈59% dos solteiros de 20–29 anos casados em 10 anos (600 pessoas, sementes 1–3); como cada união envolve duas pessoas, a taxa efetiva por pessoa é ~2× a de iniciativa.
- Desempenho (`_births`): índice mãe→filhos montado uma vez por mês em vez de `children_of` por mãe. Sem isso a suíte passou de ~8 s para ~42 s com a população crescendo; agora ~8 s. `_can_conceive` ganhou o parâmetro opcional `filhos` (chamadas antigas continuam válidas); regras de nascimento inalteradas.
- Alterado (`sim/ui_cli.py`): dica de categorias da biografia inclui `casamento`. A ficha já mostrava "Cônjuge".
- Testes: +7 (`TestCasamento`: vínculo mútuo/regras/eventos; fora das regras — menores, mesmo sexo, diferença de idade; parentes próximos; viúvo casa de novo e vínculo unilateral; taxa 45–75%; casamento leva a filhos; persistência e continuação idêntica). Regressão: os 30 anteriores passam (total 37). Verificação por mutação: desligar o bloqueio de parentesco, o limite de idade ou a regra de viuvez faz testes falharem.
- Sem mudança no esquema de save (continua v2).
- ATENÇÃO (esperado): `_marriages` consome RNG e passa a haver casamentos e nascimentos de personagens que antes ficavam solteiros; uma partida salva antes da 0.1.4 diverge da 0.1.3 a partir do ponto em que for carregada. Determinismo por semente e "carregar e continuar == não parar" continuam valendo.
- Limitações: o parceiro vem de toda a população (sem círculo social, vizinhança, classe ou afinidade de personalidade); sem separação/divórcio, sem união de pessoas do mesmo sexo, sem filhos ligados à escolha do parceiro; casar não muda sobrenome nem família.

## 0.1.3 — 2026-11-21
Nascimento de filhos durante a simulação (fecha a pendência da Fase 1).
- Adicionado (`sim/engine.py`): `_births`, executado ao fim de cada mês, depois das mortes. Uma mulher viva é elegível se tem cônjuge vivo vinculado (`spouse_id` mútuo), idade entre 15 e 44, menos de 10 filhos e nenhum parto nos últimos 15 meses. Cada mãe elegível consome 1 sorteio do RNG por mês, em ordem de id.
- Adicionado: probabilidade anual por faixa da mãe (`FERTILIDADE`: 15–19: 3%, 20–24: 10%, 25–29: 12%, 30–34: 10%, 35–39: 5%, 40–44: 1,2%). Valores ilustrativos, não estatística oficial. Medido: ≈1,87 filho por mulher em casal ativo dos 15 aos 45 (600 mulheres, sementes 1–2).
- Adicionado: o recém-nascido é um novo personagem (idade 0, nascido no mês corrente, sobrenome do pai, `family_id` da mãe, `mother_id`/`father_id`), com evento `nascimento` próprio e evento `nascimento_filho` na biografia da mãe ("Deu à luz …") e do pai ("Nasceu …"). Entra na simulação a partir do mês seguinte.
- Alterado (`sim/factory.py`): `create_character` aceita `birth=(ano, mês)` (só com idade 0). Chamadas existentes não mudam.
- Alterado (`sim/ui_cli.py`): dica de categorias da biografia inclui `nascimento_filho`. O relatório de avanço já lista os nascimentos.
- Testes: +6 (`TestNascimentos`: vínculos/data/eventos; recém-nascido no mês corrente sem aniversário; sem nascimento sem cônjuge, viúva, fora da faixa etária ou vínculo unilateral; intervalo mínimo e limite de filhos; taxa de natalidade 1,5–2,3; persistência com nascimentos e continuação idêntica). Regressão: os 24 anteriores passam (total 30).
- Sem mudança no esquema de save (continua v2) nem em saves existentes.
- ATENÇÃO (esperado): `_births` consome RNG, então uma partida salva antes da 0.1.3 diverge de como evoluiria na 0.1.2 a partir do ponto em que for carregada. Determinismo por semente e "carregar e continuar == não parar" continuam valendo na 0.1.3.
- Limitações: sem gravidez (nascimento direto, sem gestação nem gêmeos); a mãe não morre de parto; personalidade e cognição do bebê são sorteadas, não herdadas; sem efeito da saúde dos pais na fertilidade; sem idade máxima para o pai.
## 0.1.2 — 2026-11-21
Cônjuge e esquema de save v2 (pré-requisito do nascimento de filhos).
- Adicionado: campo `spouse_id` em `Character`; `create_family` vincula mãe e pai mutuamente.
- Adicionado: luto de cônjuge ("seu marido" / "sua esposa") na biografia do viúvo(a); o vínculo é preservado após a morte (histórico).
- Alterado (`sim/persistence.py`): `SCHEMA_VERSION` 1 → 2 (coluna `spouse_id` no fim da tabela `characters`). Saves v1 continuam legíveis (cônjuge vazio), sem alterar o arquivo ao carregar; o próximo salvamento grava em v2. Versões desconhecidas continuam sendo recusadas.
- Alterado: CLI mostra "Cônjuge" na ficha do personagem.
- Testes: +4 (`TestConjuge`: vínculo mútuo, persistência, luto de cônjuge, migração v1→v2); `snapshot` dos testes agora inclui `spouse_id`. Regressão: os 20 anteriores passam (total 24).
- Sem mudança de regras de simulação nem de consumo do RNG: partidas existentes evoluem de forma idêntica.
- Limitação: saves v1 não têm cônjuge; casais de partidas antigas não são reconstruídos.

## 0.1.1 — 2026-11-21
Recalibração de saúde e mortalidade.
- Alterado (`sim/engine.py`): tabela-base de mortalidade acima dos 40 anos suavizada; multiplicador de saúde passou de até 3× para até 2×; queda anual de saúde reduzida (40–59: −0,15 → −0,04/mês; 60+: −0,35 → −0,08/mês). Valores ilustrativos, não estatística oficial.
- Resultado medido: expectativa de vida simulada de ≈66 → 75,3 anos (1800 nascimentos, sementes 1–3); saúde média de quem chega vivo aos ~80 anos ≈ 66.
- Adicionado: 2 testes (`TestCalibracao`): expectativa na faixa 73–77 e saúde na velhice sem colapso (média > 40 aos ~80).
- Regressão: os 18 testes anteriores continuam passando (total 20).
- Problema conhecido nº 1 do PROJECT_STATE resolvido.

## 0.1.0 — 2026-11-21
Primeira versão executável (Fase 0 + núcleo da Fase 1).
- Tecnologia: Python 3 (biblioteca padrão) + SQLite; sem dependências externas.
- Adicionado: modelo de personagem (identidade, personalidade, cognição, saúde, pais), famílias, calendário mensal.
- Adicionado: avanço de 1 mês / 6 meses / 1 ano com relatório; aniversários, etapas de vida, saúde, mortalidade, morte e luto familiar.
- Adicionado: biografia cronológica com filtros; salvar/carregar atômico em SQLite com estado do RNG.
- Adicionado: CLI e 18 testes (unitários e de integração, inclusive execução real da CLI em processos separados).
- Corrigido durante o desenvolvimento: asserção errada em teste da CLI (19 meses a partir de jan/2026 = agosto/2027).
