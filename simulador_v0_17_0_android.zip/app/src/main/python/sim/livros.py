"""Livros (G4a/G4b, v0.15.11–0.17.0): catálogo de METADADOS (nunca o texto das obras) e leitura pelo jogador.

129 obras reais com título, autor e ano de 1ª publicação auditados.
Nível: 1 infantil (≥6 anos), 2 juvenil (≥12), 3 adulto (≥15).
Escolha e consequência: o jogador escolhe um livro por mês (exige idade e compreensão verbal mínimas: 15/30/45).
Na 1ª leitura: 30% de +1 em compreensão verbal; ganho específico pelo gênero (`GENERO_COGNICAO`: 15%/20%/25%);
e, no nível 3, 15% de +1 em raciocínio lógico (se distinto). Valores ILUSTRATIVOS.
Estado: `game.livros` {id: [ids lidos]}; última leitura em `game.convivio[(-4, id)]`.
"""
from __future__ import annotations

import random

from .models import Game

CATALOGO = [
    ("reinacoes_narizinho", "Reinações de Narizinho", "Monteiro Lobato", 1931, "infantil", 1),
    ("pequeno_principe", "O Pequeno Príncipe", "Antoine de Saint-Exupéry", 1943, "fábula", 1),
    ("alice", "Alice no País das Maravilhas", "Lewis Carroll", 1865, "fantasia", 1),
    ("ou_isto_ou_aquilo", "Ou Isto ou Aquilo", "Cecília Meireles", 1964, "poesia", 1),
    ("flicts", "Flicts", "Ziraldo", 1969, "infantil", 1),
    ("arca_de_noe", "A Arca de Noé", "Vinicius de Moraes", 1970, "poesia", 1),
    ("marcelo_marmelo", "Marcelo, Marmelo, Martelo", "Ruth Rocha", 1976, "infantil", 1),
    ("bolsa_amarela", "A Bolsa Amarela", "Lygia Bojunga", 1976, "infantil", 1),
    ("menino_maluquinho", "O Menino Maluquinho", "Ziraldo", 1980, "infantil", 1),
    ("menina_bonita", "Menina Bonita do Laço de Fita", "Ana Maria Machado", 1986, "infantil", 1),
    ("pinoquio", "As Aventuras de Pinóquio", "Carlo Collodi", 1883, "infantil", 1),
    ("magico_de_oz", "O Mágico de Oz", "L. Frank Baum", 1900, "fantasia", 1),
    ("jardim_secreto", "O Jardim Secreto", "Frances Hodgson Burnett", 1911, "infantil", 1),
    ("peter_pan", "Peter Pan", "J. M. Barrie", 1911, "fantasia", 1),
    ("narnia_leao", "O Leão, a Feiticeira e o Guarda-Roupa", "C. S. Lewis", 1950, "fantasia", 1),
    ("laranja_lima", "O Meu Pé de Laranja Lima", "José Mauro de Vasconcelos", 1968, "infantojuvenil", 2),
    ("droga_obediencia", "A Droga da Obediência", "Pedro Bandeira", 1984, "aventura", 2),
    ("hobbit", "O Hobbit", "J. R. R. Tolkien", 1937, "fantasia", 2),
    ("robinson_crusoe", "Robinson Crusoé", "Daniel Defoe", 1719, "aventura", 2),
    ("viagens_gulliver", "As Viagens de Gulliver", "Jonathan Swift", 1726, "aventura", 2),
    ("ilha_tesouro", "A Ilha do Tesouro", "Robert Louis Stevenson", 1883, "aventura", 2),
    ("viagem_centro_terra", "Viagem ao Centro da Terra", "Júlio Verne", 1864, "ficção científica", 2),
    ("vinte_mil_leguas", "Vinte Mil Léguas Submarinas", "Júlio Verne", 1870, "ficção científica", 2),
    ("volta_mundo_80", "A Volta ao Mundo em 80 Dias", "Júlio Verne", 1872, "aventura", 2),
    ("tres_mosqueteiros", "Os Três Mosqueteiros", "Alexandre Dumas", 1844, "aventura", 2),
    ("conde_monte_cristo", "O Conde de Monte Cristo", "Alexandre Dumas", 1845, "aventura", 2),
    ("moreninha", "A Moreninha", "Joaquim Manuel de Macedo", 1844, "romance", 2),
    ("sargento_milicias", "Memórias de um Sargento de Milícias", "Manuel Antônio de Almeida", 1854, "romance", 2),
    ("o_guarani", "O Guarani", "José de Alencar", 1857, "romance", 2),
    ("luciola", "Lucíola", "José de Alencar", 1862, "romance", 2),
    ("iracema", "Iracema", "José de Alencar", 1865, "romance", 2),
    ("inocencia", "Inocência", "Visconde de Taunay", 1872, "romance", 2),
    ("escrava_isaura", "A Escrava Isaura", "Bernardo Guimarães", 1875, "romance", 2),
    ("senhora", "Senhora", "José de Alencar", 1875, "romance", 2),
    ("alienista", "O Alienista", "Machado de Assis", 1882, "conto", 2),
    ("bras_cubas", "Memórias Póstumas de Brás Cubas", "Machado de Assis", 1881, "romance", 3),
    ("quincas_borba", "Quincas Borba", "Machado de Assis", 1891, "romance", 3),
    ("dom_casmurro", "Dom Casmurro", "Machado de Assis", 1899, "romance", 3),
    ("o_ateneu", "O Ateneu", "Raul Pompeia", 1888, "romance", 3),
    ("o_mulato", "O Mulato", "Aluísio Azevedo", 1881, "romance", 3),
    ("o_cortico", "O Cortiço", "Aluísio Azevedo", 1890, "romance", 3),
    ("os_sertoes", "Os Sertões", "Euclides da Cunha", 1902, "história", 3),
    ("policarpo_quaresma", "Triste Fim de Policarpo Quaresma", "Lima Barreto", 1915, "romance", 3),
    ("macunaima", "Macunaíma", "Mário de Andrade", 1928, "romance", 3),
    ("o_quinze", "O Quinze", "Rachel de Queiroz", 1930, "romance", 2),
    ("menino_engenho", "Menino de Engenho", "José Lins do Rego", 1932, "romance", 2),
    ("sao_bernardo", "São Bernardo", "Graciliano Ramos", 1934, "romance", 3),
    ("capitaes_areia", "Capitães da Areia", "Jorge Amado", 1937, "romance", 2),
    ("vidas_secas", "Vidas Secas", "Graciliano Ramos", 1938, "romance", 3),
    ("fogo_morto", "Fogo Morto", "José Lins do Rego", 1943, "romance", 3),
    ("sagarana", "Sagarana", "João Guimarães Rosa", 1946, "conto", 3),
    ("tempo_e_vento", "O Tempo e o Vento (O Continente)", "Érico Veríssimo", 1949, "romance", 3),
    ("sentimento_mundo", "Sentimento do Mundo", "Carlos Drummond de Andrade", 1940, "poesia", 3),
    ("rosa_do_povo", "A Rosa do Povo", "Carlos Drummond de Andrade", 1945, "poesia", 3),
    ("romanceiro_inconfidencia", "Romanceiro da Inconfidência", "Cecília Meireles", 1953, "poesia", 3),
    ("morte_vida_severina", "Morte e Vida Severina", "João Cabral de Melo Neto", 1955, "poesia", 2),
    ("grande_sertao", "Grande Sertão: Veredas", "João Guimarães Rosa", 1956, "romance", 3),
    ("gabriela_cravo", "Gabriela, Cravo e Canela", "Jorge Amado", 1958, "romance", 3),
    ("quarto_despejo", "Quarto de Despejo", "Carolina Maria de Jesus", 1960, "biografia", 2),
    ("hora_estrela", "A Hora da Estrela", "Clarice Lispector", 1977, "romance", 3),
    ("os_lusiadas", "Os Lusíadas", "Luís Vaz de Camões", 1572, "poesia", 3),
    ("padre_amaro", "O Crime do Padre Amaro", "Eça de Queirós", 1875, "romance", 3),
    ("primo_basilio", "O Primo Basílio", "Eça de Queirós", 1878, "romance", 3),
    ("os_maias", "Os Maias", "Eça de Queirós", 1888, "romance", 3),
    ("divina_comedia", "A Divina Comédia", "Dante Alighieri", 1321, "poesia", 3),
    ("romeu_julieta", "Romeu e Julieta", "William Shakespeare", 1597, "teatro", 2),
    ("hamlet", "Hamlet", "William Shakespeare", 1603, "teatro", 3),
    ("dom_quixote", "Dom Quixote", "Miguel de Cervantes", 1605, "romance", 3),
    ("orgulho_preconceito", "Orgulho e Preconceito", "Jane Austen", 1813, "romance", 3),
    ("frankenstein", "Frankenstein", "Mary Shelley", 1818, "ficção científica", 3),
    ("jane_eyre", "Jane Eyre", "Charlotte Brontë", 1847, "romance", 3),
    ("morro_ventos", "O Morro dos Ventos Uivantes", "Emily Brontë", 1847, "romance", 3),
    ("moby_dick", "Moby Dick", "Herman Melville", 1851, "aventura", 3),
    ("madame_bovary", "Madame Bovary", "Gustave Flaubert", 1857, "romance", 3),
    ("miseraveis", "Os Miseráveis", "Victor Hugo", 1862, "romance", 3),
    ("crime_castigo", "Crime e Castigo", "Fiódor Dostoiévski", 1866, "romance", 3),
    ("guerra_e_paz", "Guerra e Paz", "Liev Tolstói", 1869, "romance", 3),
    ("anna_karenina", "Anna Karenina", "Liev Tolstói", 1877, "romance", 3),
    ("irmaos_karamazov", "Os Irmãos Karamázov", "Fiódor Dostoiévski", 1880, "romance", 3),
    ("metamorfose", "A Metamorfose", "Franz Kafka", 1915, "novela", 3),
    ("o_processo", "O Processo", "Franz Kafka", 1925, "romance", 3),
    ("grande_gatsby", "O Grande Gatsby", "F. Scott Fitzgerald", 1925, "romance", 3),
    ("admiravel_mundo_novo", "Admirável Mundo Novo", "Aldous Huxley", 1932, "ficção científica", 3),
    ("o_estrangeiro", "O Estrangeiro", "Albert Camus", 1942, "romance", 3),
    ("revolucao_bichos", "A Revolução dos Bichos", "George Orwell", 1945, "fábula política", 2),
    ("a_peste", "A Peste", "Albert Camus", 1947, "romance", 3),
    ("mil_novecentos_84", "1984", "George Orwell", 1949, "ficção científica", 3),
    ("apanhador_centeio", "O Apanhador no Campo de Centeio", "J. D. Salinger", 1951, "romance", 2),
    ("fundacao", "Fundação", "Isaac Asimov", 1951, "ficção científica", 3),
    ("velho_e_o_mar", "O Velho e o Mar", "Ernest Hemingway", 1952, "novela", 2),
    ("fahrenheit_451", "Fahrenheit 451", "Ray Bradbury", 1953, "ficção científica", 3),
    ("sol_para_todos", "O Sol é Para Todos", "Harper Lee", 1960, "romance", 2),
    ("duna", "Duna", "Frank Herbert", 1965, "ficção científica", 3),
    ("cem_anos", "Cem Anos de Solidão", "Gabriel García Márquez", 1967, "romance", 3),
    ("o_principe", "O Príncipe", "Nicolau Maquiavel", 1532, "política", 3),
    ("discurso_metodo", "Discurso do Método", "René Descartes", 1637, "filosofia", 3),
    ("leviata", "Leviatã", "Thomas Hobbes", 1651, "política", 3),
    ("principia", "Princípios Matemáticos da Filosofia Natural", "Isaac Newton", 1687, "física", 3),
    ("espirito_leis", "O Espírito das Leis", "Montesquieu", 1748, "direito", 3),
    ("contrato_social", "Do Contrato Social", "Jean-Jacques Rousseau", 1762, "política", 3),
    ("delitos_penas", "Dos Delitos e das Penas", "Cesare Beccaria", 1764, "direito", 3),
    ("riqueza_nacoes", "A Riqueza das Nações", "Adam Smith", 1776, "economia", 3),
    ("critica_razao_pura", "Crítica da Razão Pura", "Immanuel Kant", 1781, "filosofia", 3),
    ("manifesto", "Manifesto do Partido Comunista", "Karl Marx e Friedrich Engels", 1848, "política", 3),
    ("origem_especies", "A Origem das Espécies", "Charles Darwin", 1859, "biologia", 3),
    ("o_capital", "O Capital (livro I)", "Karl Marx", 1867, "economia", 3),
    ("zaratustra", "Assim Falou Zaratustra", "Friedrich Nietzsche", 1883, "filosofia", 3),
    ("o_suicidio", "O Suicídio", "Émile Durkheim", 1897, "sociologia", 3),
    ("interpretacao_sonhos", "A Interpretação dos Sonhos", "Sigmund Freud", 1899, "psicologia", 3),
    ("etica_protestante", "A Ética Protestante e o Espírito do Capitalismo", "Max Weber", 1905, "sociologia", 3),
    ("curso_linguistica", "Curso de Linguística Geral", "Ferdinand de Saussure", 1916, "linguística", 3),
    ("casa_grande_senzala", "Casa-Grande & Senzala", "Gilberto Freyre", 1933, "sociologia", 3),
    ("logica_pesquisa", "A Lógica da Pesquisa Científica", "Karl Popper", 1934, "filosofia", 3),
    ("raizes_do_brasil", "Raízes do Brasil", "Sérgio Buarque de Holanda", 1936, "história", 3),
    ("teoria_geral", "A Teoria Geral do Emprego, do Juro e da Moeda", "John Maynard Keynes", 1936, "economia", 3),
    ("formacao_brasil_cont", "Formação do Brasil Contemporâneo", "Caio Prado Júnior", 1942, "história", 3),
    ("geografia_fome", "Geografia da Fome", "Josué de Castro", 1946, "geografia", 3),
    ("segundo_sexo", "O Segundo Sexo", "Simone de Beauvoir", 1949, "filosofia", 3),
    ("condicao_humana", "A Condição Humana", "Hannah Arendt", 1958, "filosofia", 3),
    ("formacao_economica", "Formação Econômica do Brasil", "Celso Furtado", 1959, "economia", 3),
    ("revolucoes_cientificas", "A Estrutura das Revoluções Científicas", "Thomas Kuhn", 1962, "filosofia", 3),
    ("pedagogia_oprimido", "Pedagogia do Oprimido", "Paulo Freire", 1968, "educação", 3),
    ("vigiar_e_punir", "Vigiar e Punir", "Michel Foucault", 1975, "sociologia", 3),
    ("gene_egoista", "O Gene Egoísta", "Richard Dawkins", 1976, "biologia", 3),
    ("cosmos", "Cosmos", "Carl Sagan", 1980, "ciência", 2),
    ("breve_historia_tempo", "Uma Breve História do Tempo", "Stephen Hawking", 1988, "física", 3),
    ("povo_brasileiro", "O Povo Brasileiro", "Darcy Ribeiro", 1995, "sociologia", 3),
    ("sapiens", "Sapiens", "Yuval Noah Harari", 2011, "história", 3),
    ("rapido_e_devagar", "Rápido e Devagar", "Daniel Kahneman", 2011, "psicologia", 3),
]
_POR_ID = {x[0]: x for x in CATALOGO}
IDADE_MIN = {1: 6, 2: 12, 3: 15}
VERBAL_MIN = {1: 15, 2: 30, 3: 40}

GENERO_COGNICAO = {
    "infantil": "criatividade", "fábula": "criatividade", "fantasia": "criatividade", "poesia": "criatividade",
    "infantojuvenil": "atencao", "aventura": "atencao", "teatro": "compreensao_verbal", "conto": "compreensao_verbal",
    "novela": "abstracao", "romance": "memoria", "biografia": "memoria",
    "ficção científica": "abstracao", "fábula política": "abstracao", "filosofia": "abstracao",
    "política": "resolucao_problemas", "direito": "resolucao_problemas",
    "economia": "raciocinio_logico", "física": "raciocinio_logico",
    "biologia": "aprendizagem", "ciência": "aprendizagem", "sociologia": "aprendizagem",
    "história": "memoria", "geografia": "memoria", "educação": "aprendizagem",
    "psicologia": "atencao", "linguística": "compreensao_verbal",
}


def _jogador(game: Game):
    p = game.characters.get(game.player_id) if game.player_id is not None else None
    return p if p is not None and p.alive else None


def _mes(game: Game) -> int:
    return game.year * 12 + game.month


def _motivo(game: Game, p, nivel: int, lido: bool) -> str | None:
    if lido:
        return "Já lido."
    if p.age_at(game.year, game.month) < IDADE_MIN[nivel]:
        return f"A partir de {IDADE_MIN[nivel]} anos."
    if p.cognition.get("compreensao_verbal", 0) < VERBAL_MIN[nivel]:
        return f"Exige compreensão verbal {VERBAL_MIN[nivel]}."
    return None


def interesses(game: Game, char_id: int) -> dict[str, int]:
    cont: dict[str, int] = {}
    for lid in game.livros.get(char_id, []):
        obra = _POR_ID.get(lid)
        if obra is not None:
            g = obra[4]
            cont[g] = cont.get(g, 0) + 1
    return dict(sorted(cont.items(), key=lambda kv: (-kv[1], kv[0])))


def view(game: Game, genero: str | None = None, busca: str | None = None) -> dict:
    p = _jogador(game)
    generos = sorted({x[4] for x in CATALOGO})
    if p is None:
        return {"disponivel": False, "motivo": "Nenhum personagem vivo.", "itens": [],
                "total_lidos": 0, "interesses": {}, "generos": generos}
    lidos = set(game.livros.get(p.id, []))
    ja_mes = game.convivio.get((-4, p.id)) == _mes(game)
    termo = (busca or "").strip().lower()
    itens = []
    for id_, titulo, autor, ano, gen, nivel in CATALOGO:
        if genero and gen != genero:
            continue
        if termo and termo not in titulo.lower() and termo not in autor.lower():
            continue
        m = _motivo(game, p, nivel, id_ in lidos)
        itens.append({"id": id_, "titulo": titulo, "autor": autor, "ano": ano, "genero": gen, "nivel": nivel,
                      "lido": id_ in lidos, "pode": m is None and not ja_mes, "motivo": m})
    return {"disponivel": not ja_mes, "motivo": "Você já leu um livro neste mês." if ja_mes else None,
            "itens": itens, "total_lidos": len(lidos), "interesses": interesses(game, p.id), "generos": generos}


def ler(game: Game, livro_id: str) -> dict:
    p = _jogador(game)
    if p is None:
        raise ValueError("Nenhum personagem vivo do jogador.")
    if livro_id not in _POR_ID:
        raise ValueError("Livro inexistente.")
    _, titulo, autor, _, genero, nivel = _POR_ID[livro_id]
    lidos = game.livros.setdefault(p.id, [])
    if game.convivio.get((-4, p.id)) == _mes(game):
        raise ValueError("Você já leu um livro neste mês.")
    m = _motivo(game, p, nivel, livro_id in lidos)
    if m:
        raise ValueError(m)
    r = random.Random(f"livro:{game.seed}:{_mes(game)}:{p.id}:{livro_id}")
    ganhos = []
    alvos = [("compreensao_verbal", 0.30)]
    cog_gen = GENERO_COGNICAO.get(genero)
    if cog_gen and cog_gen != "compreensao_verbal":
        alvos.append((cog_gen, {1: 0.15, 2: 0.20, 3: 0.25}[nivel]))
    if nivel == 3 and cog_gen != "raciocinio_logico":
        alvos.append(("raciocinio_logico", 0.15))
    for k, chance in alvos:
        if k not in ganhos and r.random() < chance and p.cognition.get(k, 99) < p.cognition_potential.get(k, 99):
            p.cognition[k] += 1
            ganhos.append(k)
    lidos.append(livro_id)
    game.convivio[(-4, p.id)] = _mes(game)
    game.add_event(p.id, "decisao", f"Leu \"{titulo}\", de {autor}.")
    return {"titulo": titulo, "ganhos": ganhos, "genero": genero}
