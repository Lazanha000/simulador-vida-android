"""Eventos com decisão (G1, v0.15.0): situação sorteada com SEMPRE 3 opções; o tempo para até o jogador escolher.

Regras de projeto:
- Não consome `game.rng`: o sorteio usa um gerador local derivado de (semente, mês absoluto, nº de decisões), então
  o mundo simulado continua idêntico ao das versões anteriores e o resultado é reprodutível.
- Estado em `game.decisions = {"pending": None | {...}, "count": int, "last": mês absoluto da última decisão}`;
  salvo em `meta` (save v15). Saves antigos começam sem decisão pendente.
- Só o personagem do jogador vive eventos. Efeitos: saúde, patrimônio (em fração do salário mínimo), cognição e
  personalidade (pequenos), mais uma linha na biografia. Consequências com atraso (v0.15.13):
  uma opção pode ter em seus efeitos `depois=(meses, texto, efeitos)`; a consequência é agendada em
  `game.decisions["depois"]` (salvo no JSON de `decisions`; saves antigos sem a chave funcionam) e aplicada por
  `atrasadas` quando o mês chega, com linha na biografia. Exemplos: "festa_prova" (ir à festa) e "prova_dificil" (brincar).
"""
from __future__ import annotations

import random

from .models import Game

ATIVO = True
INTERVALO_MIN = 3        # meses mínimos entre dois eventos
CHANCE_MENSAL = 0.18     # chance por mês (depois do intervalo) de surgir um evento elegível
LIMITE_POR_TURNO = 1     # eventos por chamada de avançar (o jogo para no primeiro)

# Efeitos: s = saúde, m = patrimônio em salários mínimos, c = {cognição: delta}, p = {personalidade: delta em pontos (escala 1–99)}
# Opções: (rótulo, resultado, efeitos). Condições: idade mínima/máxima e `req` (função opcional).
def _emp(c, g): return bool(c.occupation) and not c.retired
def _adulto_rico(c, g): return c.wealth > 0


EVENTOS = [
    # ---- infância (5–12) ----
    dict(id="zombaria", idade=(6, 12), peso=3, titulo="Zombaria na escola",
         texto="Um colega começa a zombar de você na frente da turma.",
         ops=[("Ignorar e seguir em frente", "Você respira fundo e finge não ouvir. Dói, mas passa.", dict(s=-1, p={"neuroticismo": 1})),
              ("Responder à altura", "Você revida com uma piada e a turma ri junto. A zombaria perde a graça.", dict(p={"extroversao": 2})),
              ("Contar à professora", "A professora conversa com a turma. Você se sente protegido(a).", dict(p={"amabilidade": 1}))]),
    dict(id="prova_dificil", idade=(6, 17), peso=3, titulo="Prova difícil amanhã",
         texto="Tem prova importante amanhã e você ainda não estudou direito.",
         ops=[("Estudar até tarde", "Você dorme pouco, mas entende a matéria.", dict(s=-1, c={"aprendizagem": 1, "memoria": 1})),
              ("Estudar um pouco e dormir bem", "Meio caminho andado e noite tranquila.", dict(c={"atencao": 1})),
              ("Deixar para lá e brincar", "Foi divertido. A prova, nem tanto.", dict(p={"conscienciosidade": -2},
                  depois=(1, "A nota veio baixa e você ouviu um sermão em casa.", dict(s=-1, p={"conscienciosidade": 1}))))]),
    dict(id="gatinho", idade=(5, 14), peso=2, titulo="Gatinho abandonado",
         texto="Você encontra um gatinho magro na rua, miando perto do portão.",
         ops=[("Levar para casa escondido", "Os pais descobrem, brigam e depois deixam ficar.", dict(m=-0.1, p={"amabilidade": 2})),
              ("Dar água e comida e deixar na rua", "Ele fica rondando a vizinhança. Você ajudou como pôde.", dict(m=-0.02, p={"amabilidade": 1})),
              ("Passar direto", "Você segue o caminho. A cena fica na cabeça por dias.", dict(p={"amabilidade": -1}))]),
    dict(id="dinheiro_chao", idade=(6, 17), peso=2, titulo="Dinheiro no chão",
         texto="Você acha uma nota dobrada no chão do pátio. Ninguém viu.",
         ops=[("Guardar para você", "Você compra um lanche e uma figurinha e fica com um pouco de culpa.", dict(m=0.05, p={"conscienciosidade": -1})),
              ("Entregar na secretaria", "A secretária agradece e anota o seu nome.", dict(p={"conscienciosidade": 2, "amabilidade": 1})),
              ("Dividir com os amigos", "Uma tarde de doce e risadas.", dict(p={"extroversao": 1, "amabilidade": 1}))]),
    dict(id="leitura", idade=(8, 17), peso=2, titulo="Professor indica uma leitura",
         texto="Seu professor sugere um livro que não é obrigatório, mas \"abre a cabeça\".",
         ops=[("Ler com atenção", "A leitura é lenta, mas você sai pensando diferente.", dict(c={"compreensao_verbal": 2, "abstracao": 1})),
              ("Ler só o resumo", "Você pega o essencial sem se esforçar muito.", dict(c={"compreensao_verbal": 1})),
              ("Ignorar a indicação", "A semana segue normal.", dict())]),
    # ---- adolescência (13–17) ----
    dict(id="festa_prova", idade=(13, 17), peso=3, titulo="Festa na véspera da prova",
         texto="Seus amigos chamam para uma festa na noite anterior a uma prova.",
         ops=[("Ir à festa", "Você se diverte muito e acorda cansado(a).", dict(s=-1, p={"extroversao": 2, "conscienciosidade": -1},
                  depois=(2, "A nota da prova saiu abaixo do esperado e você prometeu se organizar melhor.", dict(p={"conscienciosidade": 1})))),
              ("Ficar em casa estudando", "Você perde a festa, mas vai bem na prova.", dict(c={"aprendizagem": 1}, p={"conscienciosidade": 1})),
              ("Ir por uma hora e voltar cedo", "Um equilíbrio possível: um pouco de cada.", dict(p={"extroversao": 1}))]),
    dict(id="oferta_vicio", idade=(14, 17), peso=2, titulo="Uma oferta duvidosa",
         texto="Um colega oferece um cigarro \"só para experimentar\" na saída da escola.",
         ops=[("Aceitar", "A primeira tragada queima a garganta. Você tosse e todos riem.", dict(s=-3, p={"abertura": 1})),
              ("Recusar sem drama", "\"Não quero.\" Ninguém insiste.", dict(p={"conscienciosidade": 1})),
              ("Recusar e chamar o grupo para outro lugar", "Metade vai com você. A rodinha muda de assunto.", dict(p={"extroversao": 1, "amabilidade": 1}))]),
    dict(id="bico", idade=(16, 17), peso=2, titulo="Bico de fim de semana",
         texto="Um vizinho oferece um bico no sábado: ajudar numa mudança, pagamento em dinheiro.",
         ops=[("Aceitar o bico", "Cansaço de sábado, dinheiro no bolso.", dict(m=0.25, s=-1)),
              ("Negociar um valor maior", "Ele topa pagar um pouco mais pela sua firmeza.", dict(m=0.35, p={"extroversao": 1})),
              ("Recusar e descansar", "Sábado livre.", dict(s=1))]),
    dict(id="celular_novo", idade=(13, 17), peso=2, titulo="Celular novo",
         texto="Sai um celular novo que todos da turma querem. O seu está velho.",
         ops=[("Juntar dinheiro por meses", "Quando enfim compra, valeu o esforço.", dict(m=-0.2, p={"conscienciosidade": 2})),
              ("Pedir aos pais", "Eles dão um sermão e acabam ajudando.", dict()),
              ("Ficar com o que tem", "Você descobre que o velho ainda funciona.", dict(m=0.05, p={"conscienciosidade": 1}))]),
    # ---- adulto (18+) ----
    dict(id="oferta_emprego", idade=(20, 59), peso=3, req=_emp, titulo="Oferta de outro emprego",
         texto="Um conhecido indica você para uma vaga que paga um pouco mais, mas é mais arriscada.",
         ops=[("Aceitar a vaga", "Mudança de rotina e de ares. O salário sobe um pouco.", dict(m=0.4, s=-1, p={"abertura": 1})),
              ("Usar a oferta para pedir aumento", "O chefe resmunga, mas melhora sua situação.", dict(m=0.2, p={"extroversao": 1})),
              ("Recusar e ficar onde está", "Segurança acima de tudo, por ora.", dict(p={"conscienciosidade": 1}))]),
    dict(id="dor_persistente", idade=(25, 90), peso=2, titulo="Dor que não passa",
         texto="Há semanas você sente uma dor que vai e volta.",
         ops=[("Procurar um médico", "Exames, filas e um diagnóstico simples. Alívio.", dict(s=3, m=-0.3)),
              ("Tomar remédio por conta própria", "Melhora por uns dias, volta depois.", dict(s=-1, m=-0.05)),
              ("Esperar passar", "Passa... ou parece que passa.", dict(s=-2))]),
    dict(id="dinheiro_extra", idade=(18, 90), peso=2, titulo="Dinheiro extra",
         texto="Chega um dinheiro inesperado: um acerto de contas atrasado.",
         ops=[("Guardar tudo", "Reserva de emergência engordando.", dict(m=1.0, p={"conscienciosidade": 1})),
              ("Gastar com algo que você queria", "Prazer imediato.", dict(m=0.2, s=1)),
              ("Investir num curso", "O dinheiro vira conhecimento.", dict(m=0.4, c={"aprendizagem": 1, "resolucao_problemas": 1}))]),
    dict(id="curso_noite", idade=(18, 55), peso=2, titulo="Curso à noite",
         texto="Abriu uma turma noturna de um curso que combina com você. Cabe na rotina, mas apertado.",
         ops=[("Matricular-se", "As noites ficam cheias, a cabeça também.", dict(m=-0.3, s=-1, c={"aprendizagem": 2, "memoria": 1})),
              ("Fazer só o primeiro módulo", "Um gostinho do assunto, sem sufoco.", dict(m=-0.1, c={"aprendizagem": 1})),
              ("Deixar passar", "Quem sabe no semestre que vem.", dict())]),
    dict(id="emprestimo", idade=(22, 80), peso=2, req=_adulto_rico, titulo="Pedido de empréstimo",
         texto="Um parente próximo pede dinheiro emprestado, dizendo que devolve logo.",
         ops=[("Emprestar tudo que pediu", "Ele agradece muito. Resta torcer.", dict(m=-0.8, p={"amabilidade": 1})),
              ("Emprestar uma parte", "Você ajuda dentro do que dá.", dict(m=-0.3)),
              ("Recusar com jeito", "Ficou um clima estranho no almoço de domingo.", dict(p={"amabilidade": -1}))]),
    dict(id="viagem_amigos", idade=(18, 70), peso=2, titulo="Convite para viajar",
         texto="Um grupo de amigos monta uma viagem de fim de semana e chama você.",
         ops=[("Ir e curtir", "Estrada, risadas e fotos ruins. Valeu cada centavo.", dict(m=-0.4, s=1, p={"extroversao": 1})),
              ("Ir só no sábado", "Você aproveita metade e gasta metade.", dict(m=-0.15)),
              ("Ficar em casa", "Fim de semana quieto, saudade dos amigos.", dict(p={"extroversao": -1}))]),
]
EVENTOS_POR_ID = {e["id"]: e for e in EVENTOS}


def novo_estado() -> dict:
    return {"pending": None, "count": 0, "last": 0, "depois": []}


def _abs(game: Game) -> int:
    return game.year * 12 + game.month


def _rng(game: Game, extra: str) -> random.Random:
    return random.Random(f"dec:{game.seed}:{_abs(game)}:{game.decisions['count']}:{extra}")


def elegiveis(game: Game, c) -> list[dict]:
    idade = c.age_at(game.year, game.month)
    return [e for e in EVENTOS if e["idade"][0] <= idade <= e["idade"][1] and (e.get("req") is None or e["req"](c, game))]


def tentar(game: Game, c) -> dict | None:
    """Chamada a cada mês processado (pelo `views.avancar`). Cria uma decisão pendente se o sorteio acertar."""
    if not ATIVO or c is None or not c.alive or game.decisions["pending"]:
        return None
    if _abs(game) - game.decisions["last"] < INTERVALO_MIN:
        return None
    r = _rng(game, "chance")
    if r.random() >= CHANCE_MENSAL:
        return None
    lista = elegiveis(game, c)
    if not lista:
        return None
    ev = r.choices(lista, weights=[e["peso"] for e in lista])[0]
    game.decisions["pending"] = {"id": ev["id"], "ano": game.year, "mes": game.month, "pid": c.id}
    return game.decisions["pending"]


def view(game: Game) -> dict | None:
    p = game.decisions["pending"]
    if not p:
        return None
    ev = EVENTOS_POR_ID[p["id"]]
    return {"id": ev["id"], "titulo": ev["titulo"], "texto": ev["texto"], "opcoes": [o[0] for o in ev["ops"]]}


def _aplicar(game: Game, c, ef: dict) -> list[str]:
    notas = []
    if "s" in ef:
        antes = c.health
        c.health = float(max(0, min(100, c.health + ef["s"])))
        if c.health != antes:
            notas.append(f"saúde {c.health - antes:+.0f}")
    if "m" in ef:
        v = ef["m"] * game.macro["min_wage"]
        c.wealth += v
        notas.append(f"{'+' if v >= 0 else '-'}R$ {abs(v):,.0f}".replace(",", "."))
    for k, d in (ef.get("c") or {}).items():
        if k in c.cognition:
            c.cognition[k] = int(max(1, min(99, c.cognition[k] + d)))
            if k in c.cognition_potential:
                c.cognition_potential[k] = int(max(c.cognition_potential[k], c.cognition[k]))
    for k, d in (ef.get("p") or {}).items():
        if k in c.personality:
            c.personality[k] = int(max(1, min(99, c.personality[k] + d)))
    return notas


def decidir(game: Game, opcao: int | None) -> dict:
    """Resolve a decisão pendente. `opcao` None = "decidir por mim" (sorteio determinístico). Devolve o resultado."""
    p = game.decisions["pending"]
    if not p:
        raise ValueError("Não há decisão pendente.")
    ev = EVENTOS_POR_ID[p["id"]]
    auto = opcao is None
    if auto:
        opcao = _rng(game, "auto").randrange(3)
    if opcao not in (0, 1, 2):
        raise ValueError("Opção inválida.")
    c = game.characters[p["pid"]]
    rotulo, resultado, ef = ev["ops"][opcao]
    notas = _aplicar(game, c, ef) if c.alive else []
    game.add_event(c.id, "decisao", f"{ev['titulo']}: {rotulo.lower()}. {resultado}" + (f" ({', '.join(notas)})" if notas else ""))
    if ef.get("depois") and c.alive:
        meses, texto, ef2 = ef["depois"]
        game.decisions.setdefault("depois", []).append({"mes": _abs(game) + meses, "pid": c.id, "texto": texto, "ef": ef2})
    game.decisions["pending"] = None
    game.decisions["count"] += 1
    game.decisions["last"] = _abs(game)
    return {"escolhida": opcao, "auto": auto, "rotulo": rotulo, "resultado": resultado, "notas": notas}


def atrasadas(game: Game) -> int:
    """Aplica as consequências agendadas cujo mês chegou (chamada a cada mês pelo `views.avancar`). Devolve quantas."""
    fila = game.decisions.get("depois") or []
    if not fila:
        return 0
    agora = _abs(game)
    prontas = [d for d in fila if d["mes"] <= agora]
    game.decisions["depois"] = [d for d in fila if d["mes"] > agora]
    for d in prontas:
        c = game.characters.get(d["pid"])
        if c is None or not c.alive:
            continue
        notas = _aplicar(game, c, d["ef"])
        game.add_event(c.id, "decisao", f"Consequência: {d['texto']}" + (f" ({', '.join(notas)})" if notas else ""))
    return len(prontas)
