"""Avatares do jogo (v0.14.0): porta o gerador do kit de arte "Manuscrito iluminado" (gerar_arte.py) para dentro do jogo.

O código de `avatar()` e as constantes abaixo foram copiados do gerador sem alteração, para que o SVG gerado aqui seja
IDÊNTICO aos arquivos de web/arte/avatares (há teste de equivalência). O que é novo neste módulo:
  - `stage_for_age`: etapa de arte por idade (bebê 0–2, criança 3–11, adolescente 12–17, jovem 18–34, adulto 35–59, idoso 60+);
  - `look`: aparência (tom de pele 0–4 e cabelo 0–4) de cada personagem, determinística por (semente, id) e HERDADA dos pais
    (nada é salvo: depende só da semente e do parentesco, então salvar/carregar não muda ninguém);
  - `svg`/`url`: SVG completo (120×120) e rota do avatar de um personagem, usados pelo servidor web (/avatar/...).
Sem regras de simulação aqui: é só apresentação.
"""
from __future__ import annotations

import random

INK='#3b2410'; GOLD='#c9a227'; GL2='#f6e3a1'; LAZ='#1d3a8a'; RED='#b3261e'; WINE='#7a1f1f'; MAL='#2f6b45'; PURP='#5a2a6a'; OCH='#c77d1a'; ASH='#6f6a60'; PERG='#f3e5b6'; PERG2='#d8bb78'
DEFS = '''<defs><linearGradient id="au" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6e3a1"/><stop offset=".5" stop-color="#c9a227"/><stop offset="1" stop-color="#8a6a10"/></linearGradient>
<radialGradient id="pg"><stop offset="0" stop-color="#f3e5b6"/><stop offset="1" stop-color="#d8bb78"/></radialGradient>
<pattern id="dia" width="16" height="16" patternUnits="userSpaceOnUse"><path d="M8 1L15 8 8 15 1 8z" fill="none" stroke="#f6e3a1" stroke-opacity=".45"/><circle cx="8" cy="8" r="1.3" fill="#f6e3a1" fill-opacity=".6"/></pattern>
<filter id="gray"><feColorMatrix type="saturate" values="0"/></filter></defs>'''

SK = ['#f6d5b5','#e9b98f','#c98e5e','#9a6038','#5e3a22']; HC = ['#2a1a10','#5a3a1c','#a8672a','#d8b05a','#7a1f1f']
ST = {'bebe':(25,24,66,24,3.4,9),'crianca':(21,23,62,32,2.8,8.5),'adolescente':(20,24,58,38,2.4,8.5),'jovem':(19,24,56,40,2.2,8.5),'adulto':(19,24,56,42,2.2,8.5),'idoso':(19,24,58,40,2.1,8.5)}
CLO = {'bebe':('#f3ead0','#f3ead0'),'crianca':(RED,'#1d6a7a'),'adolescente':(PURP,MAL),'jovem':(WINE,LAZ),'adulto':(MAL,'#7a4a1a'),'idoso':('#8a8478','#5a3a1c')}
def avatar(stage, sex, si=1, hi=None, dead=False):
    rx, ry, cy, bw, er, es = ST[stage]; cx = 60; f = sex == 'f'
    skin = SK[si]; hair = '#d9d6cf' if stage == 'idoso' else HC[hi if hi is not None else (1 if f else 0)]
    cloth = CLO[stage][0 if f else 1]; by = cy + ry + 4; o = ''
    bow_col = '#e58aa0' if f else '#7aa6d8'
    beard_op = 1 if stage == 'idoso' else .3
    beard_st = INK if stage == 'idoso' else 'none'
    brow_col = hair if stage != 'idoso' else '#9a968c'
    gray_flt = ' filter="url(#gray)"' if dead else ''
    ring_in = GL2 if not dead else '#ccc'
    if f and stage in ('adolescente','jovem','adulto'):
        o += f'<path d="M{cx-rx-4} {cy} Q{cx-rx-8} {cy+ry+18} {cx-rx+2} {cy+ry+20} L{cx+rx-2} {cy+ry+20} Q{cx+rx+8} {cy+ry+18} {cx+rx+4} {cy}z" fill="{hair}" stroke="{INK}" stroke-width="1"/>'
    if f and stage == 'crianca':
        o += ''.join(f'<circle cx="{cx+s*(rx+5)}" cy="{cy+6}" r="7" fill="{hair}" stroke="{INK}" stroke-width="1"/>' for s in (-1, 1))
    if f and stage == 'idoso': o += f'<circle cx="{cx}" cy="{cy-ry-3}" r="9" fill="{hair}" stroke="{INK}" stroke-width="1"/>'
    o += f'<path d="M{cx-bw} 124 Q{cx-bw} {by} {cx} {by} Q{cx+bw} {by} {cx+bw} 124z" fill="{cloth}" stroke="{INK}" stroke-width="1.2"/>'
    o += f'<path d="M{cx-11} {by+1} Q{cx} {by+13} {cx+11} {by+1}" fill="none" stroke="{GOLD}" stroke-width="2.5"/>'
    o += f'<rect x="{cx-6}" y="{cy+ry-6}" width="12" height="12" fill="{skin}" stroke="{INK}" stroke-width="1"/>'
    o += f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="{skin}" stroke="{INK}" stroke-width="1.2"/>'
    if stage in ('jovem','adulto','idoso') and f: o += ''.join(f'<circle cx="{cx+s*rx}" cy="{cy+10}" r="1.9" fill="{GOLD}"/>' for s in (-1, 1))
    if stage == 'bebe':
        o += f'<path d="M{cx-rx-1} {cy-4} Q{cx-rx} {cy-ry-8} {cx} {cy-ry-8} Q{cx+rx} {cy-ry-8} {cx+rx+1} {cy-4} Q{cx} {cy-ry+6} {cx-rx-1} {cy-4}z" fill="#f3ead0" stroke="{INK}" stroke-width="1.2"/>'
        o += f'<circle cx="{cx-4}" cy="{cy-ry+4}" r="3.5" fill="{bow_col}"/><circle cx="{cx+4}" cy="{cy-ry+4}" r="3.5" fill="{bow_col}"/>'
    elif not (stage == 'idoso' and not f):
        d0, d1 = (6, 10) if f else (2, 6)
        o += f'<path d="M{cx-rx-1} {cy-2} Q{cx-rx-2} {cy-ry-6} {cx} {cy-ry-6} Q{cx+rx+2} {cy-ry-6} {cx+rx+1} {cy-2} Q{cx+rx-4} {cy-ry+d0} {cx} {cy-ry+d1} Q{cx-rx+4} {cy-ry+d0} {cx-rx-1} {cy-2}z" fill="{hair}" stroke="{INK}" stroke-width="1.1"/>'
    else:
        o += ''.join(f'<ellipse cx="{cx+s*(rx-2)}" cy="{cy-6}" rx="5" ry="8" fill="{hair}" stroke="{INK}" stroke-width="1"/>' for s in (-1, 1))
    if not f and stage in ('adulto','idoso'):
        o += f'<path d="M{cx-rx+2} {cy+6} Q{cx-rx} {cy+ry+6} {cx} {cy+ry+8} Q{cx+rx} {cy+ry+6} {cx+rx-2} {cy+6} Q{cx} {cy+ry-2} {cx-rx+2} {cy+6}z" fill="{hair}" fill-opacity="{beard_op}" stroke="{beard_st}" stroke-width="1"/>'
    ey = cy + 2
    if dead: o += ''.join(f'<path d="M{cx+s*es-3} {ey} Q{cx+s*es} {ey+3} {cx+s*es+3} {ey}" fill="none" stroke="{INK}" stroke-width="1.4"/>' for s in (-1, 1))
    else: o += ''.join(f'<circle cx="{cx+s*es}" cy="{ey}" r="{er}" fill="{INK}"/>' + (f'<circle cx="{cx+s*es+1}" cy="{ey-1}" r="1" fill="#fff"/>' if stage in ('bebe','crianca') else '') for s in (-1, 1))
    if stage in ('adolescente','jovem','adulto','idoso'): o += ''.join(f'<path d="M{cx+s*es-4} {ey-6} Q{cx+s*es} {ey-8} {cx+s*es+4} {ey-6}" fill="none" stroke="{brow_col}" stroke-width="1.6"/>' for s in (-1, 1))
    if stage in ('bebe','crianca'): o += ''.join(f'<circle cx="{cx+s*(es+5)}" cy="{ey+7}" r="4" fill="#e58aa0" fill-opacity=".45"/>' for s in (-1, 1))
    o += f'<path d="M{cx-1} {ey+4} q3 4 -1 6" fill="none" stroke="#7a4a2a" stroke-width="1" stroke-opacity=".7"/>'
    my = cy + ry - 8; mw = 3 if stage == 'bebe' else 5
    o += f'<path d="M{cx-mw} {my} Q{cx} {my+(0 if dead else 4)} {cx+mw} {my}" fill="none" stroke="{WINE}" stroke-width="1.4" stroke-linecap="round"/>'
    if stage in ('adulto','idoso'): o += ''.join(f'<path d="M{cx+s*(es+4)} {ey+2} l{s*3} 2M{cx+s*(es+4)} {ey+5} l{s*3} 1" stroke="{INK}" stroke-opacity=".45" stroke-width=".9"/>' for s in (-1, 1))
    if stage == 'idoso': o += ''.join(f'<circle cx="{cx+s*es}" cy="{ey}" r="5.5" fill="none" stroke="{INK}" stroke-width="1.2"/>' for s in (-1, 1)) + f'<path d="M{cx-es+5.5} {ey} H{cx+es-5.5}" stroke="{INK}" stroke-width="1.2"/>'
    bg = '#3a3a3a' if dead else LAZ; ring = '#9a9a9a' if dead else 'url(#au)'
    body = (f'<clipPath id="cl"><circle cx="60" cy="60" r="54"/></clipPath><circle cx="60" cy="60" r="57" fill="{bg}"/><circle cx="60" cy="60" r="55" fill="url(#dia)"/>'
            f'<g clip-path="url(#cl)"{gray_flt}>{o}</g>'
            + ('<path d="M10 84 L36 112 L26 117 L5 94z" fill="#111" clip-path="url(#cl)"/>' if dead else '')
            + f'<circle cx="60" cy="60" r="57" fill="none" stroke="{ring}" stroke-width="5"/><circle cx="60" cy="60" r="52" fill="none" stroke="{ring_in}" stroke-opacity=".6"/>')
    return body

# --------------------------------------------------------------------------------------------------
# API do jogo (nova na v0.14.0)
ETAPAS_ARTE = ((0, 'bebe'), (3, 'crianca'), (12, 'adolescente'), (18, 'jovem'), (35, 'adulto'), (60, 'idoso'))
PESO_PELE = (0.22, 0.28, 0.25, 0.15, 0.10)    # sorteio dos fundadores (sem pais); ILUSTRATIVO
PESO_CABELO = (0.35, 0.38, 0.14, 0.08, 0.05)  # preto, castanho, ruivo-acobreado, loiro, vinho


def stage_for_age(age: int) -> str:
    nome = ETAPAS_ARTE[0][1]
    for inicio, n in ETAPAS_ARTE:
        if age >= inicio:
            nome = n
    return nome


def _pick(rng: random.Random, pesos) -> int:
    x, acc = rng.random() * sum(pesos), 0.0
    for i, p in enumerate(pesos):
        acc += p
        if x < acc:
            return i
    return len(pesos) - 1


def look(game, c) -> tuple[int, int]:
    """(tom de pele 0–4, cabelo 0–4) de `c`. Fundadores sorteiam; filhos herdam a média da pele dos pais (±1) e o cabelo de um
    dos pais (8% de mutação). Determinístico por (semente, id) e em cache na própria partida (não é salvo)."""
    cache = game.__dict__.setdefault("_look_cache", {})
    if c.id in cache:
        return cache[c.id]
    rng = random.Random(f"{game.seed}:look:{c.id}")
    pais = game.parents_of(c)
    if not pais:
        res = (_pick(rng, PESO_PELE), _pick(rng, PESO_CABELO))
    else:
        olhares = [look(game, p) for p in pais]
        media = sum(o[0] for o in olhares) / len(olhares)
        pele = int(media + rng.choice((-0.6, 0.0, 0.0, 0.6)) + 0.5)
        cabelo = rng.choice([o[1] for o in olhares])
        if rng.random() < 0.08:
            cabelo = _pick(rng, PESO_CABELO)
        res = (min(4, max(0, pele)), cabelo)
    cache[c.id] = res
    return res


def svg(stage: str, sex: str, skin: int, hair: int, dead: bool = False) -> str:
    """SVG 120×120 completo (mesmo invólucro dos arquivos do kit). `sex` = 'f' ou 'm'."""
    if stage not in ST or sex not in ('f', 'm') or not 0 <= skin < len(SK) or not 0 <= hair < len(HC):
        raise ValueError("parâmetros de avatar inválidos")
    corpo = avatar(stage, sex, skin, hair, dead)
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120">{DEFS}{corpo}</svg>'


def url(game, c, age: int) -> str:
    """Rota do avatar de `c` (a idade já deve ser a da data de referência: hoje, ou a do falecimento)."""
    pele, cabelo = look(game, c)
    return f"/avatar/{stage_for_age(age)}_{c.sex.lower()}_{pele}_{cabelo}{'' if c.alive else '_d'}.svg"
