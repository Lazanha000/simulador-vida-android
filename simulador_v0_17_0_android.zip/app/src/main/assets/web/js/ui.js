// Helpers de interface. Todo texto entra por textContent/createTextNode (nomes digitados nunca viram HTML).
export const $ = (s, r = document) => r.querySelector(s);
export const A = (p) => `arte/${p}`;   // caminho de um arquivo do kit de arte

export function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'style') e.style.cssText = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2).toLowerCase(), v);
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid != null && kid !== false) e.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return e;
}

export const img = (src, cls, alt = '') => h('img', { src, class: cls, alt, draggable: 'false' });

export class ErroApi extends Error {
  constructor(msg, status, dados) { super(msg); this.status = status; this.dados = dados || {}; }
}

export async function api(caminho, corpo) {
  const opt = corpo === undefined ? {} : {
    method: 'POST', headers: { 'X-Sim': '1', 'Content-Type': 'application/json' }, body: JSON.stringify(corpo),
  };
  let r;
  try { r = await fetch(`/api/${caminho}`, opt); }
  catch { throw new ErroApi('Sem conexão com o jogo. O servidor foi encerrado? Reabra o programa e recarregue a página.', 0); }
  const d = await r.json().catch(() => ({ erro: 'Resposta inválida do servidor.' }));
  if (!r.ok) throw new ErroApi(d.erro || 'Erro desconhecido.', r.status, d);
  return d;
}

export const qs = (o) => {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(o || {})) if (v !== '' && v != null) p.set(k, v);
  const s = p.toString();
  return s ? `?${s}` : '';
};

// --- camadas (toast, diálogo, espera) ---
const camadas = () => document.getElementById('camadas');

export function toast(msg) {
  const t = h('div', { class: 'toast', role: 'status' }, msg);
  camadas().append(t);
  setTimeout(() => t.remove(), 3700);
}

export function espera(texto = 'Passando o tempo…') {
  const e = h('div', { class: 'espera', role: 'alert' }, texto);
  camadas().append(e);
  return () => e.remove();
}

// dialogo({ topo, titulo, corpo, botoes:[{rotulo, fn, p}], luto, fechavel, aoFechar }) -> { fechar }
// O fn de um botão roda ANTES de o diálogo fechar (síncrono); se devolver uma promessa, ela é aguardada depois.
export function dialogo({ topo, titulo, corpo, botoes = [], luto = false, fechavel = true, aoFechar }) {
  const fundo = h('div', { class: 'fundo', role: 'dialog', 'aria-modal': 'true' });
  let aberto = true;
  const fechar = () => {
    if (!aberto) return;
    aberto = false; fundo.remove(); document.removeEventListener('keydown', tecla); if (aoFechar) aoFechar();
  };
  const tecla = (ev) => { if (ev.key === 'Escape' && fechavel && camadas().lastElementChild === fundo) fechar(); };
  const dlg = h('div', { class: `dlg${luto ? ' luto' : ''}` },
    topo, titulo && h('h2', null, titulo), corpo,
    h('div', { class: 'acoes' }, botoes.map((b) => h('button', {
      class: `btn${b.p ? ' p' : ''} m`, type: 'button',
      onclick: async () => {
        const r = b.fn ? b.fn() : undefined;
        if (b.fechar !== false) fechar();
        await r;
      },
    }, b.rotulo))));
  fundo.append(dlg);
  if (fechavel) fundo.addEventListener('mousedown', (ev) => { if (ev.target === fundo) fechar(); });
  document.addEventListener('keydown', tecla);
  camadas().append(fundo);
  dlg.querySelector('button')?.focus({ preventScroll: true });
  return { fechar };
}

// Pergunta sim/não; fechar por Esc ou clique fora conta como "não".
export function confirmar(titulo, texto, rotuloSim = 'Sim', rotuloNao = 'Não') {
  return new Promise((res) => {
    let r = false;
    dialogo({ titulo, corpo: h('p', { class: 'texto' }, texto), aoFechar: () => res(r),
      botoes: [{ rotulo: rotuloSim, fn: () => { r = true; } }, { rotulo: rotuloNao }] });
  });
}

// --- componentes do kit ---
export const rotuloIdade = (n) => (n === 0 ? 'Ao nascer' : n === 1 ? '1 ano' : `${n} anos`);

export function barra(valor, cor) {
  return h('span', { class: 'track' }, h('span', { class: `fill ${cor}`, style: `--v:${Math.max(0, Math.min(100, valor))}%` }));
}

export const brl = (n) => n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

// --- formulários ---
export function campo(rotulo, entrada, dica) {
  return h('label', { class: 'campo' }, h('span', null, rotulo), entrada, dica && h('small', { class: 'dica' }, dica));
}

// Controle segmentado: opcoes = [[valor, rótulo], ...]; el.valor() devolve o escolhido.
export function seg(opcoes, inicial, aoMudar) {
  let v = inicial;
  const el = h('div', { class: 'seg', role: 'group' });
  const desenhar = () => el.replaceChildren(...opcoes.map(([val, rot]) => h('button', {
    type: 'button', class: val === v ? 'on' : '', 'aria-pressed': String(val === v),
    onclick: () => { v = val; desenhar(); if (aoMudar) aoMudar(v); },
  }, rot)));
  desenhar();
  el.valor = () => v;
  return el;
}
