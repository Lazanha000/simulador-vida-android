"""Simulador de Vida Brasileiro — pacote principal."""

__version__ = "0.14.4"
