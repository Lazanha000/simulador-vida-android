// Simulador de Vida Brasileiro — aplicação (telas: título, nova partida, carregar, jogo).
import { $, A, ErroApi, api, barra, campo, confirmar, dialogo, espera, h, img, rotuloIdade, seg, toast } from './ui.js';
import { abrirMenu, abrirPainel, fecharTodas, fecharTopo, haPainelAberto, iniciarPaineis } from './panels.js';

const app = $('#app'), tela = $('#tela');
const S = { est: null, itens: [], mais: false, restantes: 0, maxSeq: -1, ocupado: false, bandeja: null, versao: '' };
const CAP = { bom: 'verde', ruim: 'vermelha', neutro: 'azul' };

// --- texto maior/menor (preferência do navegador) ---
function aplicarTexto(delta = 0) {
  let z = parseFloat(localStorage.getItem('simTexto') || '1');
  z = Math.min(1.4, Math.max(0.85, Math.round((z + delta * 0.1) * 10) / 10));
  localStorage.setItem('simTexto', String(z));
  document.documentElement.style.setProperty('--z', String(z));
  if (delta) toast(`Tamanho do texto: ${Math.round(z * 100)}%`);
}

const mostrar = (cls, ...nos) => { app.className = `app${cls ? ` ${cls}` : ''}`; tela.replaceChildren(...nos); };
const tratar = (e) => { toast(e.message || String(e)); };

// ====================== título ======================
async function telaTitulo() {
  fecharTodas();
  let saves = { saves: [], ultimo: null, versao: '' };
  try { saves = await api('saves'); } catch (e) { tratar(e); }
  S.versao = saves.versao;
  const ult = saves.ultimo;
  const botoes = [];
  if (ult) botoes.push(h('button', { class: 'btn', type: 'button', onclick: () => carregar(ult.arquivo) }, 'Continuar'));
  botoes.push(h('button', { class: 'btn', type: 'button', onclick: telaNova }, 'Novo jogo'));
  if (!ult && saves.saves.length) botoes.push(h('button', { class: 'btn', type: 'button', onclick: telaCarregar }, 'Carregar jogo'));
  const outras = ult && saves.saves.length > 1 && h('button', { class: 'link', type: 'button', onclick: telaCarregar }, 'Outras partidas…');
  mostrar('titulo', h('section', { class: 'screen', style: 'padding:0' },
    h('div', { class: 'tit-faixa' }, h('b', null, 'Simulador de Vida'), h('i', null, 'Brasileiro')),
    ult && h('div', { class: 'tit-ultimo' }, `${ult.nome}${ult.jogador ? ` · ${ult.jogador}` : ''}${ult.data ? ` · ${ult.data}` : ''}`),
    h('div', { class: 'tit-botoes' }, botoes, outras),
    h('div', { class: 'tit-versao' }, `v${saves.versao}`)));
}

// ====================== nova partida ======================
function telaNova() {
  fecharTodas();
  const nome = h('input', { type: 'text', maxlength: 60, value: 'Minha vida' });
  const semente = h('input', { type: 'number', placeholder: 'aleatória' });
  const erro = h('div', { class: 'erro' });
  const campos = h('div');
  const modo = seg([['nascer', 'Nascer'], ['avulso', 'Personagem'], ['familia', 'Família']], 'nascer', () => desenhar());
  const f = {
    sobrenome: h('input', { type: 'text', maxlength: 30, placeholder: 'aleatório' }),
    primeiro: h('input', { type: 'text', maxlength: 30, placeholder: 'aleatório' }),
    sexo: seg([['', 'Aleatório'], ['F', 'Feminino'], ['M', 'Masculino']], ''),
    irmaos: h('input', { type: 'number', min: 0, max: 5, value: 1 }),
    idade: h('input', { type: 'number', min: 0, max: 110, value: 25 }),
    filhos: h('input', { type: 'number', min: 0, max: 10, value: 2 }),
  };
  const desenhar = () => {
    const m = modo.valor();
    campos.replaceChildren(...[
      h('p', { class: 'dica', style: 'margin:0 0 4px' }, {
        nascer: 'Você nasce agora numa família nova, com pais e irmãos mais velhos, e vive a vida inteira.',
        avulso: 'Um personagem sozinho, de qualquer idade (sem pais na simulação).',
        familia: 'Uma família pronta: mãe, pai e filhos; você joga com o filho mais velho (ou a mãe, se não houver filhos).',
      }[m]),
      m === 'avulso' && h('div', { class: 'duas' }, campo('Idade', f.idade), campo('Nome', f.primeiro)),
      m === 'nascer' && campo('Seu nome', f.primeiro),
      (m === 'nascer' || m === 'avulso') && campo('Sexo', f.sexo),
      campo('Sobrenome da família', f.sobrenome),
      m === 'nascer' && campo('Irmãos mais velhos (0 a 5)', f.irmaos),
      m === 'familia' && campo('Filhos (0 a 10)', f.filhos)].filter(Boolean));
  };
  desenhar();
  const comecar = async (sobrescrever = false) => {
    erro.textContent = '';
    const m = modo.valor();
    const corpo = { nome: nome.value, semente: semente.value, modo: m, sobrenome: f.sobrenome.value, nome_personagem: f.primeiro.value,
      sexo: f.sexo.valor(), irmaos: +f.irmaos.value, idade: +f.idade.value, filhos: +f.filhos.value, sobrescrever };
    const fim = espera('Criando a partida…');
    try { const est = await api('novo', corpo); fim(); await entrarNoJogo(est); }
    catch (e) {
      fim();
      if (e.dados?.existe) { if (await confirmar('Partida existente', 'Já existe um save com esse nome. Sobrescrever?', 'Sobrescrever', 'Cancelar')) comecar(true); }
      else erro.textContent = e.message;
    }
  };
  mostrar('', h('section', { class: 'screen' },
    h('div', { class: 'titulo-faixa' }, 'Nova partida'),
    h('div', { class: 'corpo' }, campo('Nome da partida', nome), campo('Como começar', modo), campos,
      campo('Semente', semente, 'Mesma semente = mesmo mundo. Deixe vazio para sortear.'), erro),
    h('div', { class: 'rodape' }, h('button', { class: 'btn', type: 'button', onclick: () => comecar() }, 'Começar'),
      h('button', { class: 'btn p', type: 'button', onclick: telaTitulo }, 'Voltar'))));
}

// ====================== carregar ======================
async function telaCarregar() {
  fecharTodas();
  let d;
  try { d = await api('saves'); } catch (e) { tratar(e); return telaTitulo(); }
  const lista = d.saves.length ? d.saves.map((s) => h('button', {
    class: 'save', type: 'button', disabled: !s.legivel, onclick: () => carregar(s.arquivo),
  }, img(A('icones/icone_carregar.svg'), ''), h('span', null, h('div', { class: 'n' }, s.nome),
    h('div', { class: 's' }, s.legivel ? [s.jogador, s.data].filter(Boolean).join(' · ') : 'save ilegível ou de versão não suportada'),
    h('div', { class: 's' }, `salvo em ${new Date(s.mtime * 1000).toLocaleString('pt-BR')}`))))
    : h('div', { class: 'vazio' }, img(A('ui/slot_barra_icone_96.svg'), ''), 'Nenhuma partida salva ainda.');
  mostrar('', h('section', { class: 'screen' }, h('div', { class: 'titulo-faixa' }, 'Carregar jogo'), h('div', { class: 'corpo' }, lista),
    h('div', { class: 'rodape' }, h('button', { class: 'btn p', type: 'button', onclick: telaTitulo }, 'Voltar'))));
}

async function carregar(arquivo) {
  const fim = espera('Abrindo a partida…');
  try { const est = await api('carregar', { arquivo }); fim(); await entrarNoJogo(est); }
  catch (e) { fim(); tratar(e); }
}

// ====================== jogo ======================
const NAV = [['escola', 'Escola'], ['bens', 'Bens'], null, ['relacoes', 'Relações'], ['trabalho', 'Trabalho']];

async function entrarNoJogo(est) {
  S.est = est; S.itens = []; S.maxSeq = -1;
  fecharTodas();
  const cab = h('header', { class: 'cab' },
    h('button', { class: 'av', type: 'button', id: 'av', 'aria-label': 'Ficha do personagem', onclick: () => abrirPainel('ficha', { id: S.est.jogador.id }) }),
    h('button', { class: 'id', type: 'button', id: 'idj', onclick: () => abrirPainel('ficha', { id: S.est.jogador.id }) }, h('div', { class: 'nome' }), h('div', { class: 'sub' })),
    h('button', { class: 'placa', type: 'button', id: 'placa', 'aria-label': 'Bens e finanças', onclick: () => abrirPainel('bens') }, h('b'), h('small')));
  const data = h('div', { class: 'datebar' }, h('span', { id: 'data' }),
    h('button', { class: 'pill', type: 'button', id: 'foco', onclick: abrirFoco }, 'Foco'),
    h('button', { class: 'pill', type: 'button', onclick: abrirAcoes }, 'Ações'),
    h('button', { class: 'pill', type: 'button', onclick: abrirMenu }, img(A('icones/icone_config.svg'), ''), 'Menu'));
  const barras = h('div', { class: 'barras', id: 'barras' });
  const nav = h('nav', { class: 'nav' }, NAV.map((n) => n
    ? h('button', { class: 'nb', type: 'button', onclick: () => abrirPainel(n[0]) }, img(A(`icones/icone_${n[0]}.svg`), ''), h('span', null, n[1]))
    : h('div', { style: 'position:relative;width:92px;flex:none' },
      h('button', { class: 'selo', type: 'button', id: 'selo', 'aria-label': 'Avançar o tempo', onclick: alternarBandeja }), h('span', { class: 'selo-rotulo' }, 'Avançar'))));
  mostrar('', h('section', { class: 'screen' }, cab, data, h('main', { class: 'feed', id: 'feed' }), barras, nav));
  desenharEstado();
  await carregarDiario();
  if (est.decisao) abrirDecisao(est.decisao);   // save carregado no meio de uma decisão
}

function desenharEstado() {
  const e = S.est, j = e.jogador;
  app.classList.toggle('luto', !!e.luto);
  $('#data').textContent = e.partida.data;
  if (!j) return;
  $('#av').replaceChildren(img(j.avatar, ''));
  const id = $('#idj');
  id.firstChild.textContent = j.nome; id.lastChild.textContent = `${j.idade} anos · ${j.sub}`;
  const placa = $('#placa');
  placa.classList.toggle('neg', e.dinheiro.negativo);
  placa.firstChild.textContent = e.dinheiro.linha; placa.lastChild.textContent = e.dinheiro.sub;
  $('#barras').replaceChildren(...e.barras.map((b) => h('button', { class: 'bar', type: 'button', onclick: () => abrirPainel(b.painel), 'aria-label': `${b.rotulo}: ${b.valor}` },
    h('span', { class: 'rot' }, b.rotulo), barra(b.valor, b.id), h('i', null, b.valor))));
  const bf = $('#foco');
  if (bf && e.foco) bf.textContent = `Foco: ${e.foco.opcoes.find((o) => o.id === e.foco.atual)?.rotulo ?? ''}${e.foco.atual === 'estudar' && e.foco.area !== 'geral' ? ' (' + (e.foco.areas.find((a) => a.id === e.foco.area)?.rotulo ?? '') + ')' : ''}`;
  const selo = $('#selo');
  if (selo) selo.disabled = S.ocupado || !e.pode_avancar;
}

// --- diário ---
async function carregarDiario(extra = 0, novosApos = S.maxSeq) {
  try {
    const d = await api(`diario?limite=${Math.max(120, S.itens.length + extra)}`);
    S.itens = d.itens; S.mais = d.mais; S.restantes = d.restantes;
  } catch (e) { tratar(e); return; }
  desenharDiario(novosApos);
}

function desenharDiario(novosApos = S.maxSeq) {
  const feed = $('#feed');
  if (!feed) return;
  const frag = document.createDocumentFragment();
  if (S.mais) frag.append(h('button', { class: 'link mais-antigos', type: 'button', onclick: maisAntigos }, `Ver anos anteriores (${S.restantes} registros)`));
  let ultima = null, k = 0;
  for (const e of S.itens) {
    if (e.idade !== ultima) {
      if (ultima !== null) frag.append(h('div', { class: `divisor d${(k++ % 3) + 1}` }));
      frag.append(h('div', { class: 'faixa-idade' }, rotuloIdade(e.idade)));
      frag.append(entrada(e, true, novosApos));
      ultima = e.idade;
    } else frag.append(entrada(e, false, novosApos));
  }
  if (S.est?.luto) frag.append(h('div', { class: 'luto-faixa' }, `In memoriam`));
  feed.replaceChildren(frag);
  S.maxSeq = S.itens.length ? Math.max(...S.itens.map((e) => e.seq)) : -1;
  feed.scrollTop = feed.scrollHeight;
}

function entrada(e, primeira, novosApos) {
  const marca = primeira
    ? h('span', { class: `cap ${CAP[e.tom] || 'azul'}`, 'aria-hidden': 'true' }, [...e.texto][0])
    : img(A(e.icone), 'mini');
  return h('article', { class: `ev ${e.tom}${e.seq > novosApos && novosApos >= 0 ? ' novo' : ''}` }, marca,
    h('div', { class: 'tx' }, h('span', { class: 'dt' }, e.data), primeira ? [...e.texto].slice(1).join('') : e.texto));
}

async function maisAntigos() {
  const feed = $('#feed'), alt = feed.scrollHeight;
  try {
    const d = await api(`diario?limite=${S.itens.length + 120}`);
    S.itens = d.itens; S.mais = d.mais; S.restantes = d.restantes;
  } catch (e) { return tratar(e); }
  const max = S.maxSeq;
  desenharDiario(max + 1e9);   // sem destaque
  feed.scrollTop = feed.scrollHeight - alt;
  S.maxSeq = max;
}

// --- avanço do tempo ---
function alternarBandeja() {
  if (S.ocupado) return;
  if (S.bandeja) { S.bandeja.remove(); S.bandeja = null; return; }
  const fechar = () => { S.bandeja?.remove(); S.bandeja = null; document.removeEventListener('mousedown', fora, true); };
  const fora = (ev) => { if (S.bandeja && !S.bandeja.contains(ev.target) && ev.target.id !== 'selo') fechar(); };
  const op = [['selo_1mes', 1, '1 mês'], ['selo_6meses', 6, '6 meses'], ['selo_1ano', 12, '1 ano']];
  S.bandeja = h('div', { class: 'bandeja', role: 'menu' }, op.map(([arq, n, rot]) => h('button', {
    type: 'button', role: 'menuitem', onclick: () => { fechar(); avancar(n); },
  }, img(A(`ui/${arq}.svg`), ''), h('span', null, rot))));
  $('.screen').append(S.bandeja);
  document.addEventListener('mousedown', fora, true);
}

async function avancar(meses) {
  if (S.ocupado) return;
  S.ocupado = true; desenharEstado();
  const t = setTimeout(() => { S.fimEspera = espera(meses >= 12 ? 'Um ano se passa…' : meses >= 6 ? 'Meio ano se passa…' : 'O mês passa…'); }, 250);
  try {
    const rel = await api('avancar', { meses });
    S.est = rel.estado;
    await carregarDiario(rel.meus.length, S.maxSeq);
    desenharEstado();
    clearTimeout(t); S.fimEspera?.(); S.fimEspera = null;
    if (rel.decisao) abrirDecisao(rel.decisao); else relatorio(rel);
  } catch (e) { clearTimeout(t); S.fimEspera?.(); S.fimEspera = null; tratar(e); }
  finally { S.ocupado = false; desenharEstado(); }
}

// Ações da vida (v0.15.12): agrupa Amigos, Conhecer, Encontros e Livros num só botão (a barra da data ficava apertada).
function abrirAcoes() {
  let janela = null;
  const itens = [['Amigos', abrirAmigos], ['Conhecer alguém', conhecerAlguem], ['Encontros', abrirEncontros], ['Livros', abrirLivros]];
  janela = dialogo({ titulo: 'Ações', corpo: h('div', { class: 'decisao' }, itens.map(([rotulo, fn]) => h('button', { class: 'btn m opcao', type: 'button',
    onclick: () => { janela.fechar(); fn(); } }, rotulo))) });
}

// Livros (v0.15.11): 1 leitura por mês; só a primeira leitura de cada obra rende efeito.
function abrirLivros() {
  const l = S.est.livros || { itens: [] };
  let janela = null;
  const corpo = h('div', { class: 'decisao' }, [
    h('p', {}, l.motivo || `Lidos: ${l.total_lidos || 0}. Escolha um livro (1 por mês).`),
    ...l.itens.map((i) => h('button', { class: 'btn m opcao', type: 'button', disabled: !i.pode,
      onclick: async () => { try { const r = await api('ler', { id: i.id }); S.est = r.estado; janela.fechar(); desenharEstado(); toast(`Você leu "${r.leitura.titulo}".`); } catch (x) { tratar(x); } } },
    `${i.lido ? '✓ ' : ''}${i.titulo} — ${i.autor}, ${i.ano}${i.motivo ? ` (${i.motivo})` : ''}`))]);
  janela = dialogo({ titulo: 'Livros', corpo });
}

// Aplicativo de encontros (v0.15.7): só maiores de 18; 3 candidatos por mês; escolher = começar a namorar.
function abrirEncontros() {
  const e = S.est.encontros || {};
  let janela = null;
  if (e.namoro) {
    const n = e.namoro;
    const agir = (rota, txt) => async () => { try { const r = await api(rota, {}); S.est = r.estado; janela.fechar(); desenharEstado(); toast(txt(r.resultado)); } catch (x) { tratar(x); } };
    janela = dialogo({ titulo: 'Namoro', corpo: h('div', { class: 'decisao' }, [
      h('p', {}, `Você namora ${n.nome}, ${n.idade} anos, há ${n.meses} meses.`),
      h('button', { class: 'btn m opcao', type: 'button', disabled: !n.pode_pedir, onclick: agir('namoro/pedir', (r) => (r.aceitou ? `${r.nome} aceitou! Vocês se casaram.` : `${r.nome} ainda não estava pronto(a).`)) }, n.pode_pedir ? 'Pedir em casamento' : `Pedir em casamento — ${n.motivo}`),
      h('button', { class: 'btn m opcao', type: 'button', onclick: agir('namoro/terminar', (r) => `Você terminou o namoro com ${r.nome}.`) }, 'Terminar o namoro')]) });
    return;
  }
  const aviso = h('p', {}, 'Só para maiores de 18 anos.');
  const lista = e.disponivel ? e.candidatos.map((c) => h('button', { class: 'btn m opcao', type: 'button',
    onclick: async () => { try { const r = await api('encontro', { slot: c.slot }); S.est = r.estado; janela.fechar(); desenharEstado(); toast(`Você começou a namorar ${r.par.nome}.`); } catch (x) { tratar(x); } } },
  `${c.nome}, ${c.idade} anos`)) : [h('p', {}, e.motivo || 'Indisponível.')];
  janela = dialogo({ titulo: 'Encontros', corpo: h('div', { class: 'decisao' }, [aviso, ...lista]) });
}

// Conversar com um amigo (v0.15.4): 1 vez por mês por amigo; a amizade esfria menos.
function abrirAmigos() {
  const lista = S.est.amigos || [];
  let janela = null;
  const agir = (rota, a, txt) => async () => { try { const r = await api(rota, { id: a.id }); S.est = r.estado; janela.fechar(); desenharEstado(); toast(txt(r)); } catch (e) { tratar(e); } };
  const corpo = h('div', { class: 'decisao' }, lista.length ? lista.flatMap((a) => [
    h('p', {}, `${a.nome}, ${a.idade} anos${a.proximo ? ' — amizade próxima' : a.interacoes ? ` — ${a.interacoes} momento(s) juntos` : ''}${a.conversou ? ' — já passaram um tempo juntos este mês' : ''}`),
    h('button', { class: 'btn m opcao', type: 'button', disabled: a.conversou, onclick: agir('conversar', a, (r) => `Você conversou com ${r.conversa.nome}.`) }, 'Conversar'),
    h('button', { class: 'btn m opcao', type: 'button', disabled: a.conversou, onclick: agir('convidar', a, (r) => `Você saiu com ${r.convite.nome}.`) }, a.custo > 0 ? `Convidar para sair (R$ ${String(a.custo.toFixed(2)).replace('.', ',')})` : 'Convidar para sair'),
  ]) : [h('p', {}, 'Você ainda não tem amigos. Use "Conhecer".')]);
  janela = dialogo({ titulo: 'Amigos', corpo });
}

// Conhecer alguém (v0.15.3): gera uma pessoa nova e já cria a amizade.
function conhecerAlguem() {
  const locais = S.est.locais || [];
  if (locais.length < 2) { conhecerEm('vizinhanca'); return; }
  let janela = null;
  janela = dialogo({ titulo: 'Onde conhecer?', corpo: h('div', { class: 'decisao' }, locais.map((l) => h('button', { class: 'btn m opcao', type: 'button',
    onclick: () => { janela.fechar(); conhecerEm(l.id); } }, l.rotulo))) });
}
async function conhecerEm(local) {
  try { const r = await api('conhecer', { local }); S.est = r.estado; desenharEstado(); toast(`Você conheceu ${r.novo.nome}, ${r.novo.idade} anos.`); } catch (e) { tratar(e); }
}

// Foco do período (v0.15.1): vale até o jogador mudar.
function abrirFoco() {
  const f = S.est.foco;
  const dicas = { equilibrado: 'Nada muda.', estudar: 'Notas melhores e cognição cresce aos poucos; cansa um pouco.',
    trabalhar: 'Se empregado, ganha extra; cansa.', socializar: 'Mais chance de fazer amigos.', descansar: 'Recupera a saúde.' };
  let janela = null;
  const corpo = h('div', { class: 'decisao' }, f.opcoes.map((o) => h('button', { class: 'btn m opcao', type: 'button',
    onclick: async () => { try { if (o.id === 'estudar' && f.areas) { janela.fechar(); abrirArea(); return; } S.est = await api('foco', { foco: o.id }); janela.fechar(); desenharEstado(); toast(`Foco: ${o.rotulo}.`); } catch (e) { tratar(e); } } },
  `${o.id === f.atual ? '✓ ' : ''}${o.rotulo} — ${dicas[o.id]}`)));
  janela = dialogo({ titulo: 'Foco do período', corpo });
}

// Área de estudo (v0.15.2): aparece ao escolher "Estudar".
function abrirArea() {
  const f = S.est.foco;
  let janela = null;
  const corpo = h('div', { class: 'decisao' }, f.areas.map((a) => h('button', { class: 'btn m opcao', type: 'button',
    onclick: async () => { try { S.est = await api('foco', { foco: 'estudar', area: a.id }); janela.fechar(); desenharEstado(); toast(`Estudar: ${a.rotulo}.`); } catch (e) { tratar(e); } } },
  `${a.id === f.area ? '✓ ' : ''}${a.rotulo}`)));
  janela = dialogo({ titulo: 'Área de estudo', corpo });
}

// Evento com decisão (v0.15.0): 3 opções grandes (alvo de toque), "decidir por mim" e resultado em seguida.
function abrirDecisao(d) {
  let janela = null;
  const escolher = async (opcao) => {
    if (S.ocupado) return;
    S.ocupado = true;
    try {
      const r = await api('decidir', { opcao });
      S.est = r.estado;
      janela?.fechar();
      await carregarDiario(1, S.maxSeq);
      desenharEstado();
      dialogo({ titulo: d.titulo, corpo: h('div', null,
        h('p', { class: 'texto' }, `${r.auto ? 'O destino escolheu: ' : 'Você escolheu: '}${r.rotulo}.`),
        h('p', { class: 'texto' }, r.resultado),
        r.notas.length > 0 && h('p', { class: 'nota' }, r.notas.join(' · '))), botoes: [{ rotulo: 'Continuar', p: true }] });
    } catch (e) { tratar(e); }
    finally { S.ocupado = false; desenharEstado(); }
  };
  const corpo = h('div', { class: 'decisao' }, h('p', { class: 'texto' }, d.texto),
    d.opcoes.map((rot, i) => h('button', { class: 'btn m opcao', type: 'button', onclick: () => escolher(i) }, rot)),
    h('button', { class: 'btn m auto', type: 'button', onclick: () => escolher('auto') }, 'Decidir por mim'));
  janela = dialogo({ titulo: d.titulo, corpo, fechavel: false });
}

function plural(n, um, varios) { return `${n} ${n === 1 ? um : varios}`; }

function relatorio(rel) {
  if (rel.jogador_morreu) return dialogoMorte(rel);
  const mundo = rel.mundo, partes = [];
  if (mundo.nascimentos) partes.push(plural(mundo.nascimentos, 'nascimento', 'nascimentos'));
  if (mundo.mortes) partes.push(plural(mundo.mortes, 'morte', 'mortes'));
  if (mundo.casamentos) partes.push(plural(mundo.casamentos, 'casamento', 'casamentos'));
  if (mundo.divorcios) partes.push(plural(mundo.divorcios, 'divórcio', 'divórcios'));
  if (mundo.namoros) partes.push(plural(mundo.namoros, 'namoro novo', 'namoros novos'));
  if (rel.meses < 6 && !rel.ano_novo) {
    toast(`${rel.data}${rel.meus.length ? ` · ${plural(rel.meus.length, 'acontecimento', 'acontecimentos')} para você` : ' · nada de especial'}`);
    return;
  }
  const an = rel.ano_novo;
  const destaques = rel.meus.filter((e) => e.cat !== 'aniversario' && e.cat !== 'etapa_de_vida');
  const corpo = h('div', null,
    h('div', { class: 'ev' }, h('span', { class: 'cap azul' }, 'D'),
      h('div', { class: 'tx' }, `e ${rel.de} a ${rel.data}: ${plural(rel.meses, 'mês', 'meses')} de vida.`)),
    destaques.length
      ? h('div', null, destaques.slice(0, 8).map((e) => h('div', { class: `ev ${e.tom}` }, img(A(e.icone), 'mini'),
        h('div', { class: 'tx' }, h('span', { class: 'dt' }, e.data), e.texto))),
        destaques.length > 8 && h('p', { class: 'nota' }, `E mais ${destaques.length - 8} no diário.`))
      : h('p', { class: 'nota' }, 'Nada de especial aconteceu com você, além de mais um aniversário.'),
    partes.length > 0 && h('p', { class: 'nota' }, `No mundo: ${partes.join(', ')}.`),
    an && h('div', null, h('div', { class: 'divisor d3' }),
      h('div', { class: 'ev' }, img(A('eventos/evento_ciclo_economico.svg'), 'mini'), h('div', { class: 'tx' }, `Clima econômico de ${an.ano}: ${an.clima}.`)),
      h('div', { class: 'ev' }, img(A('eventos/evento_inflacao.svg'), 'mini'), h('div', { class: 'tx' }, `Inflação do ano passado: ${an.inflacao_anterior_fmt}. Salário mínimo agora: ${an.salario_minimo}.`))),
    rel.salvo && h('p', { class: 'nota' }, 'Partida salva.'));
  dialogo({ topo: an ? h('div', { class: 'faixa-ano' }, `Ano novo · ${an.ano}`) : null, titulo: an ? null : 'Relatório do turno', corpo, botoes: [{ rotulo: 'Continuar' }] });
}

async function dialogoMorte(rel) {
  const j = S.est.jogador;
  let herdeiros = [];
  try { herdeiros = (await api('herdeiros')).itens; } catch { /* segue sem lista */ }
  let janela = null;
  const morte = [...rel.meus].reverse().find((e) => e.cat === 'morte');
  const corpo = h('div', null,
    h('p', { class: 'texto', style: 'text-align:center;margin:2px 0 8px' }, `${j.nome}${morte ? ` — ${morte.texto.replace(/^Faleceu/, 'faleceu')}` : ' faleceu.'}`),
    h('div', { style: 'display:flex;justify-content:center' }, img(j.avatar, '')),
    herdeiros.length
      ? h('div', null, h('h3', { style: 'font:400 1.2em var(--fk);margin:8px 0 2px;text-align:center' }, 'Continuar a história como…'),
        herdeiros.map((p) => h('button', { class: 'pes', type: 'button', onclick: async () => { try { S.est = await api('jogador', { id: p.id }); janela?.fechar(); await entrarNoJogo(S.est); } catch (e) { tratar(e); } } },
          img(p.avatar, ''), h('span', null, h('div', { class: 'n' }, p.nome), h('div', { class: 's' }, p.sub)), h('span', { class: 'rel' }, p.rel))))
      : h('p', { class: 'nota' }, 'Não há parentes vivos para continuar a história. Crie outro personagem ou volte ao título.'));
  janela = dialogo({ topo: h('div', { class: 'faixa-luto' }, 'In memoriam'), corpo, luto: true,
    botoes: herdeiros.length
      ? [{ rotulo: 'Ver biografia', fn: () => abrirPainel('biografia') }, { rotulo: 'Fechar', p: true }]
      : [{ rotulo: 'Novo personagem', p: true, fn: () => abrirPainel('personagens') },
        { rotulo: 'Voltar ao título', fn: () => irParaTitulo() },
        { rotulo: 'Ver biografia', fn: () => abrirPainel('biografia') },
        { rotulo: 'Fechar' }] });
}

// ====================== ações globais usadas pelos painéis ======================
async function salvar() {
  try { const r = await api('salvar', {}); S.est = r.estado; toast(`Partida salva (${r.arquivo}).`); } catch (e) { tratar(e); }
}

async function irParaTitulo() {
  if (S.est?.tem_jogo && S.est.partida.sujo && !S.est.partida.autosave) {
    if (await confirmar('Salvar antes de sair?', 'Há alterações não salvas.', 'Salvar e sair', 'Sair sem salvar')) await salvar();
  }
  try { await api('fechar', {}); } catch (e) { tratar(e); }
  S.est = null;
  await telaTitulo();
}

iniciarPaineis({
  jogar: async (id) => { S.est = await api('jogador', { id }); await entrarNoJogo(S.est); toast(`Agora você joga com ${S.est.jogador.primeiro}.`); },
  salvar,
  carregar: async () => { fecharTodas(); await irParaTitulo().then(telaCarregar); },
  titulo: irParaTitulo,
  texto: aplicarTexto,
  atualizar: async () => { S.est = await api('estado'); desenharEstado(); },
});

document.addEventListener('keydown', (ev) => {
  if (ev.key === 'Escape' && haPainelAberto() && !$('.fundo')) fecharTopo();
});

// ====================== início ======================
(async function iniciar() {
  aplicarTexto(0);
  try {
    const est = await api('estado');
    if (est.tem_jogo) await entrarNoJogo(est); else await telaTitulo();
  } catch (e) {
    mostrar('', h('section', { class: 'screen' }, h('div', { class: 'titulo-faixa' }, 'Sem conexão'), h('p', { class: 'erro' }, e instanceof ErroApi ? e.message : String(e))));
  }
})();
