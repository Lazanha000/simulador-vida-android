"""Conhecer alguém (G3a, v0.15.3): o jogador gera uma pessoa nova (vizinhança) e já fica amigo dela.

Escolha e consequência: botão "Conhecer"; nasce um personagem novo (nome, idade, personalidade, cognição
próprios, persistido como qualquer outro) e a amizade entra no círculo do jogador (máx. 8 amigos vivos).
Limite: 1 pessoa nova por mês (v0.15.5). Regras de idade (explícitas): jogador menor de 18 só conhece menores de 18; adulto só conhece adultos;
diferença de idade dentro do limite das amizades; mínimo 6 anos. Onde conhecer (G3g, v0.15.8→0.15.10): vizinhança (padrão); escola (se o jogador estuda: o conhecido estuda,
idade ±1 → colega de turma, com os efeitos de colegas nas amizades); faculdade (se cursa: o conhecido cursa, ≥18,
idade ±4). Sorteio por gerador local: o `game.rng`
é restaurado ao final (o mundo simulado não muda por causa desta ação).
"""
from __future__ import annotations

import random

from . import engine, factory
from .models import Game


def locais(game: Game) -> list[dict]:
    p = game.characters.get(game.player_id) if game.player_id is not None else None
    out = [{"id": "vizinhanca", "rotulo": "Na vizinhança"}]
    if p is not None and p.alive:
        if p.in_school:
            out.append({"id": "escola", "rotulo": "Na escola"})
        if getattr(p, "in_college", False):
            out.append({"id": "faculdade", "rotulo": "Na faculdade"})
    return out


def conhecer(game: Game, local: str = "vizinhanca") -> dict:
    p = game.characters.get(game.player_id) if game.player_id is not None else None
    if p is None or not p.alive:
        raise ValueError("Nenhum personagem vivo do jogador.")
    now = (game.year, game.month)
    idade = p.age_at(*now)
    if idade < engine.IDADE_AMIZADE_MIN:
        raise ValueError(f"Só a partir dos {engine.IDADE_AMIZADE_MIN} anos é possível conhecer pessoas.")
    if engine._alive_friend_count(game, p) >= engine.MAX_AMIGOS:
        raise ValueError(f"Você já tem {engine.MAX_AMIGOS} amigos; o círculo está cheio.")
    chave = (-1, p.id)   # marca "último mês em que o jogador conheceu alguém" (reaproveita game.convivio)
    mes = game.year * 12 + game.month
    if game.convivio.get(chave) == mes:
        raise ValueError("Você já conheceu alguém neste mês; tente de novo no próximo.")
    r = random.Random(f"conhecer:{game.seed}:{game.year * 12 + game.month}:{p.id}:{game.next_char_id}")
    if local not in {x["id"] for x in locais(game)}:
        raise ValueError("Você não pode conhecer alguém nesse lugar agora.")
    gap = 1 if local == "escola" else 4 if local == "faculdade" else engine._max_age_gap(idade)
    lo, hi = idade - gap, idade + gap
    lo, hi = (max(lo, engine.IDADE_AMIZADE_MIN), min(hi, 17)) if idade < 18 else (max(lo, 18), min(hi, 90))
    if lo > hi:
        lo = hi = max(engine.IDADE_AMIZADE_MIN, min(idade, 17)) if idade < 18 else max(18, idade)
    idade_novo = r.randint(lo, hi)
    estado = game.rng.getstate()
    try:
        novo = factory.create_character(game, idade_novo, r.choice("FM"))
    finally:
        game.rng.setstate(estado)
    if local == "escola":
        novo.in_school = True
        novo.schooling_years = max(novo.schooling_years, p.schooling_years) if idade_novo >= 18 else novo.schooling_years
    elif local == "faculdade":
        novo.in_college, novo.in_school = True, False
        novo.schooling_years, novo.higher_years = max(12, novo.schooling_years), p.higher_years
    game.add_friendship(p.id, novo.id)
    game.convivio[chave] = mes
    onde = {"escola": " na escola", "faculdade": " na faculdade"}.get(local, "")
    game.add_event(p.id, "amizade", f"Conheceu {novo.full_name}{onde} e fez amizade.")
    game.add_event(novo.id, "amizade", f"Conheceu {p.full_name}{onde} e fez amizade.")
    return {"id": novo.id, "nome": novo.full_name, "idade": idade_novo, "local": local}
