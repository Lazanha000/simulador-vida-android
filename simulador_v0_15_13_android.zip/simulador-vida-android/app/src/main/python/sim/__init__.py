"""Simulador de Vida Brasileiro — pacote principal."""

__version__ = "0.15.13"
