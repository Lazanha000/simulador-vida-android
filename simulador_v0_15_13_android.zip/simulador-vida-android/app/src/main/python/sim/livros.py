"""Livros (G4a, v0.15.11): catálogo de METADADOS (nunca o texto das obras) e leitura pelo jogador.

Lote 1 (28 obras, preenchido de memória do desenvolvedor-IA: AUDITAR título/autor/ano/gênero item a item antes de
expandir; a meta é ~1.000 obras em lotes de ~100). Nível: 1 infantil (≥6 anos), 2 juvenil (≥12), 3 adulto (≥15).
Escolha e consequência: o jogador escolhe um livro por mês (se tem idade e compreensão verbal mínimas: 15/30/45 para
os níveis 1/2/3). Na PRIMEIRA leitura de cada obra: 30% de +1 em compreensão verbal (até o potencial); nível 3 também
15% de +1 em raciocínio lógico; evento "decisao" na biografia. Reler não dá efeito (e não é oferecido). Sorteio local.
Estado: `game.livros` {id do personagem: [ids lidos]}; mês da última leitura em `game.convivio[(-4, id)]`.
"""
from __future__ import annotations

import random

from .models import Game

# (id, título, autor, ano da 1ª publicação, gênero, nível)
CATALOGO = [
    ("reinacoes_narizinho", "Reinações de Narizinho", "Monteiro Lobato", 1931, "infantil", 1),
    ("pequeno_principe", "O Pequeno Príncipe", "Antoine de Saint-Exupéry", 1943, "fábula", 1),
    ("alice", "Alice no País das Maravilhas", "Lewis Carroll", 1865, "fantasia", 1),
    ("hobbit", "O Hobbit", "J. R. R. Tolkien", 1937, "fantasia", 2),
    ("robinson_crusoe", "Robinson Crusoé", "Daniel Defoe", 1719, "aventura", 2),
    ("moby_dick", "Moby Dick", "Herman Melville", 1851, "aventura", 3),
    ("iracema", "Iracema", "José de Alencar", 1865, "romance", 2),
    ("o_guarani", "O Guarani", "José de Alencar", 1857, "romance", 2),
    ("alienista", "O Alienista", "Machado de Assis", 1882, "conto", 2),
    ("bras_cubas", "Memórias Póstumas de Brás Cubas", "Machado de Assis", 1881, "romance", 3),
    ("dom_casmurro", "Dom Casmurro", "Machado de Assis", 1899, "romance", 3),
    ("o_cortico", "O Cortiço", "Aluísio Azevedo", 1890, "romance", 3),
    ("capitaes_areia", "Capitães da Areia", "Jorge Amado", 1937, "romance", 2),
    ("vidas_secas", "Vidas Secas", "Graciliano Ramos", 1938, "romance", 3),
    ("grande_sertao", "Grande Sertão: Veredas", "João Guimarães Rosa", 1956, "romance", 3),
    ("hora_estrela", "A Hora da Estrela", "Clarice Lispector", 1977, "romance", 3),
    ("dom_quixote", "Dom Quixote", "Miguel de Cervantes", 1605, "romance", 3),
    ("miseraveis", "Os Miseráveis", "Victor Hugo", 1862, "romance", 3),
    ("orgulho_preconceito", "Orgulho e Preconceito", "Jane Austen", 1813, "romance", 3),
    ("frankenstein", "Frankenstein", "Mary Shelley", 1818, "ficção científica", 3),
    ("crime_castigo", "Crime e Castigo", "Fiódor Dostoiévski", 1866, "romance", 3),
    ("metamorfose", "A Metamorfose", "Franz Kafka", 1915, "novela", 3),
    ("cem_anos", "Cem Anos de Solidão", "Gabriel García Márquez", 1967, "romance", 3),
    ("revolucao_bichos", "A Revolução dos Bichos", "George Orwell", 1945, "fábula política", 2),
    ("mil_novecentos_84", "1984", "George Orwell", 1949, "ficção científica", 3),
    ("origem_especies", "A Origem das Espécies", "Charles Darwin", 1859, "ciência", 3),
    ("manifesto", "Manifesto do Partido Comunista", "Karl Marx e Friedrich Engels", 1848, "política", 3),
    ("o_capital", "O Capital (livro I)", "Karl Marx", 1867, "economia", 3),
]
_POR_ID = {x[0]: x for x in CATALOGO}
IDADE_MIN = {1: 6, 2: 12, 3: 15}
VERBAL_MIN = {1: 15, 2: 30, 3: 45}


def _jogador(game: Game):
    p = game.characters.get(game.player_id) if game.player_id is not None else None
    return p if p is not None and p.alive else None


def _mes(game: Game) -> int:
    return game.year * 12 + game.month


def _motivo(game: Game, p, nivel: int, lido: bool) -> str | None:
    if lido:
        return "Já lido."
    if p.age_at(game.year, game.month) < IDADE_MIN[nivel]:
        return f"A partir de {IDADE_MIN[nivel]} anos."
    if p.cognition.get("compreensao_verbal", 0) < VERBAL_MIN[nivel]:
        return f"Exige compreensão verbal {VERBAL_MIN[nivel]}."
    return None


def view(game: Game) -> dict:
    p = _jogador(game)
    if p is None:
        return {"disponivel": False, "motivo": "Nenhum personagem vivo.", "itens": []}
    lidos = set(game.livros.get(p.id, []))
    ja_mes = game.convivio.get((-4, p.id)) == _mes(game)
    itens = []
    for id_, titulo, autor, ano, genero, nivel in CATALOGO:
        m = _motivo(game, p, nivel, id_ in lidos)
        itens.append({"id": id_, "titulo": titulo, "autor": autor, "ano": ano, "genero": genero, "nivel": nivel,
                      "lido": id_ in lidos, "pode": m is None and not ja_mes, "motivo": m})
    return {"disponivel": not ja_mes, "motivo": "Você já leu um livro neste mês." if ja_mes else None,
            "itens": itens, "total_lidos": len(lidos)}


def ler(game: Game, livro_id: str) -> dict:
    p = _jogador(game)
    if p is None:
        raise ValueError("Nenhum personagem vivo do jogador.")
    if livro_id not in _POR_ID:
        raise ValueError("Livro inexistente.")
    _, titulo, autor, _, _, nivel = _POR_ID[livro_id]
    lidos = game.livros.setdefault(p.id, [])
    if game.convivio.get((-4, p.id)) == _mes(game):
        raise ValueError("Você já leu um livro neste mês.")
    m = _motivo(game, p, nivel, livro_id in lidos)
    if m:
        raise ValueError(m)
    r = random.Random(f"livro:{game.seed}:{_mes(game)}:{p.id}:{livro_id}")
    ganhos = []
    for k, chance in (("compreensao_verbal", 0.30), ("raciocinio_logico", 0.15 if nivel == 3 else 0.0)):
        if r.random() < chance and p.cognition.get(k, 99) < p.cognition_potential.get(k, 99):
            p.cognition[k] += 1
            ganhos.append(k)
    lidos.append(livro_id)
    game.convivio[(-4, p.id)] = _mes(game)
    game.add_event(p.id, "decisao", f"Leu \"{titulo}\", de {autor}.")
    return {"titulo": titulo, "ganhos": ganhos}
