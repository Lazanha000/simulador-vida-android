# ROADMAP

> **PRIORIDADE ATUAL: trilha de jogabilidade G1–G4 (decisões do jogador, estudo com escolha, mundo social vivo, livros). Ver `DIRECAO.md`.** O jogador ainda não toma decisões; isso vem antes de novas fases de mundo.

Estado: [x] feito · [~] parcial · [ ] pendente

- [x] Fase 0 — Planejamento técnico
- [x] Fase 1 — Núcleo funcional (personagem, família, calendário, idade, tempo, salvar/carregar, interface, calibração de mortalidade, cônjuge, nascimento de filhos)
- [~] Fase 2 — Vida social (feitos: nascimentos 0.1.3, casamento 0.1.4, divórcio + herança de traços + desenvolvimento cognitivo + parentesco ampliado + mortalidade materna 0.2.0, círculo social/amizades 0.3.0; fim de amizades, gêmeos e guarda dos filhos 0.10.0; namoro 0.11.0; gestação 0.12.0; pensão alimentícia e licença-maternidade 0.13.0; pendentes: NPCs autônomos (objetivos próprios), memória detalhada de relacionamentos, inimizade, uniões do mesmo sexo)
- [~] Fase 3 — Educação (feito: educação básica 0.4.0; ensino superior básico e retorno aos estudos 0.5.0; pendentes: escolas/turmas concretas, cursos/áreas, pós-graduação, custo e renda)
- [ ] Fase 4 — Conhecimento
- [~] Fase 5 — Trabalho (feito: primeiro emprego, ocupação por formação/aptidão, desemprego, mudança de ocupação e aposentadoria 0.6.0; informal/formal, promoção, experiência e colegas de trabalho 0.7.0; empresas genéricas com vagas, fechamento e fundação 0.8.0; pendentes: concursos, empreendedorismo, meio período, produtividade/hierarquia das empresas)
- [~] Fase 6 — Economia (feito 0.7.0: salário, renda, aposentadoria com benefício, domicílio e custo de vida, patrimônio, auxílio social, herança, panorama econômico; 0.9.0 ciclo econômico; 0.9.1 seguro-desemprego; 0.9.2 prêmio salarial por porte; 0.13.0 inflação, salário mínimo dinâmico, impostos e orçamento do Estado; pendentes: crédito/imóveis, retroalimentação do Estado)
- [ ] Fase 7 — Mundo
- [ ] Fase 8 — Política e acontecimentos
- [ ] Fase 9 — Integração

Próximas microatualizações: ver PROJECT_STATE.md.
